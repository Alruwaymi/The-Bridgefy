import logging
from pymongo import MongoClient

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# MongoDB Configuration
MONGO_URI = "mongodb://localhost:27017"
DATABASE_NAME = "bridgefy_db"
STICKER_COLLECTION = "Sticker"
MESSAGE_COLLECTION = "Message"

# Global variables to hold mapping data
mapping = {}
reverse_map = {}

def load_mapping():
    """
    Load the sticker mapping and reverse mapping from MongoDB.
    """
    global mapping, reverse_map
    try:
        client = MongoClient(MONGO_URI)
        db = client[DATABASE_NAME]
        collection = db[STICKER_COLLECTION]

        # Fetch the mapping document
        sticker_data = collection.find_one()
        if not sticker_data:
            raise ValueError("No sticker mapping found in MongoDB")

        sticker_data.pop("_id", None)
        mapping.update(sticker_data)

        # Generate reverse mapping
        reverse_map.clear()
        for language, letters in mapping.items():
            for letter, path in letters.items():
                if path:
                    reverse_map[path] = (language, letter)

        client.close()
        logger.info("Mapping loaded successfully from MongoDB.")

    except Exception as e:
        logger.error(f"Error loading mapping from MongoDB: {e}")

def save_message_to_mongodb(original_text, stickers, language):
    """
    Save text-to-sticker messages into MongoDB.
    """
    try:
        client = MongoClient(MONGO_URI)
        db = client[DATABASE_NAME]
        message_collection = db[MESSAGE_COLLECTION]

        stickers = [sticker if sticker else "SPACE" for sticker in stickers]  # Handle spaces as "SPACE"

        message_data = {
            "language": language,
            "original_text": original_text,
            "stickers": stickers
        }

        result = message_collection.insert_one(message_data)
        print(f"✅ Text-to-Sticker Message inserted with ID: {result.inserted_id}")

        client.close()
    except Exception as e:
        logger.error(f"❌ Error saving text-to-sticker message to MongoDB: {e}")

def save_decoded_message_to_mongodb(stickers, decoded_text, language):
    """
    Save the decoded sticker-to-text messages into MongoDB.
    """
    try:
        client = MongoClient(MONGO_URI)
        db = client[DATABASE_NAME]
        message_collection = db[MESSAGE_COLLECTION]

        stickers = [sticker if sticker else "SPACE" for sticker in stickers]  # Handle spaces as "SPACE"

        message_data = {
            "language": language,
            "decoded_text": decoded_text,
            "stickers": stickers
        }

        result = message_collection.insert_one(message_data)
        print(f"✅ Sticker-to-Text Message inserted with ID: {result.inserted_id}")

        client.close()
    except Exception as e:
        logger.error(f"❌ Error saving sticker-to-text message to MongoDB: {e}")

def retrieve_latest_message():
    """
    Retrieve and display the latest stored message from MongoDB.
    """
    try:
        client = MongoClient(MONGO_URI)
        db = client[DATABASE_NAME]
        message_collection = db[MESSAGE_COLLECTION]

        message = message_collection.find_one(sort=[("_id", -1)])  # Get the latest message
        client.close()

        if not message:
            print("\nNo stored messages found in MongoDB.")
            return

        stickers = message['stickers']
        stickers = [None if sticker == "SPACE" else sticker for sticker in stickers]  # Convert "SPACE" back to None

        # Decode stickers if possible
        decoded_text = message.get("decoded_text", "N/A")
        original_text = message.get("original_text", "N/A")

        print("\n--- Latest Stored Message in MongoDB ---")
        print(f"Language: {message['language']}")
        print(f"Original Text: {original_text}")
        print(f"Stickers: {message['stickers']}")
        print(f"Decoded Text: {decoded_text}")  
        print("-" * 40)

    except Exception as e:
        logger.error(f"Error retrieving messages from MongoDB: {e}")

def stickers_to_text(stickers, language="asl"):
    """
    Convert a list of sticker paths to text for ASL or Arabic.
    """
    if not reverse_map:
        logger.error("Reverse mapping is not loaded. Call load_mapping() first.")
        return ""
    
    text = []
    print("\n--- DEBUG: Decoding Stickers ---")  # DEBUG
    for sticker in stickers:
        print(f"Sticker: {sticker}")  # Debugging each sticker

        if sticker is None:
            text.append(" ")  # Space
        elif sticker in reverse_map:
            lang, letter = reverse_map[sticker]
            if lang == language:
                text.append(letter)
            else:
                print(f"⚠️ WARNING: Sticker '{sticker}' belongs to '{lang}', expected '{language}'")
        else:
            print(f"❌ ERROR: Sticker '{sticker}' not found in reverse mapping")
            text.append("?")  # Placeholder for unknown sticker paths
    print("-----------------------------------")

    return ''.join(text)

def text_to_stickers(text, language="asl"):
    """
    Convert text to sticker paths for ASL or Arabic.
    """
    if not mapping:
        logger.error("Mapping is not loaded. Call load_mapping() first.")
        return []
    
    stickers = []
    if language == "asl":
        text = text.upper()  # Convert to uppercase for ASL
    
    for char in text:
        if char == " ":
            stickers.append(None)
        elif char in mapping.get(language, {}):
            stickers.append(mapping[language][char])  # Add sticker path
        else:
            logger.warning(f"Unknown Character: {char}")
            stickers.append(f"[unknown: {char}]")  # Placeholder for unknown characters
    return stickers

def messaging_simulation():
    """
    Simulate sending and receiving messages with ASL and Arabic support.
    """
    load_mapping()  # Load the mappings at the start

    while True:
        print("\n--- Messaging Simulation ---")
        print("Options: ")
        print("1. Send a text message (Text → Stickers)")
        print("2. Send stickers (Stickers → Text)")
        print("3. View latest stored message")
        print("4. Quit")
        choice = input("Choose an option (1, 2, 3, or 4): ").strip()

        if choice == "4":
            print("Exiting the simulation. Goodbye!")
            break

        if choice == "1":
            language = input("Enter the language ('asl' or 'arabic'): ").strip().lower()
            if language not in ["asl", "arabic"]:
                print("Invalid language. Please choose 'asl' or 'arabic'.")
                continue

            text = input(f"Enter the message to send ({language.upper()}): ").strip()
            stickers = text_to_stickers(text, language=language)

            print("\n--- Sending Message ---")
            print(f"Original Text: {text}")
            print(f"Sticker Paths: {stickers}")

            save_message_to_mongodb(text, stickers, language)

        elif choice == "2":
            language = input("Enter the language ('asl' or 'arabic'): ").strip().lower()
            if language not in ["asl", "arabic"]:
                print("Invalid language. Please choose 'asl' or 'arabic'.")
                continue

            sticker_input = input("Enter sticker paths (comma-separated, use 'None' for spaces): ").strip()
            stickers = [None if path.strip().lower() == "none" else path.strip() for path in sticker_input.split(",")]

            print("\n--- Sending Stickers ---")
            print(f"Sticker Paths: {stickers}")

            # Decode stickers to text
            decoded_text = stickers_to_text(stickers, language=language)
            print(f"\nDecoded Text: {decoded_text}")

            # Save decoded message to MongoDB
            save_decoded_message_to_mongodb(stickers, decoded_text, language)

        elif choice == "3":
            # Retrieve and display the latest stored message
            retrieve_latest_message()

        else:
            print("Invalid option. Please choose again.")

if __name__ == "__main__":
    messaging_simulation()
