import { Module } from '@nestjs/common';
import { StickersService } from './stickers.service';
import { StickersController } from './stickers.controller';
import { PrismaService } from 'src/common/prisma.service';
import { CloudinaryModule } from 'src/cloudinary/cloudinary.module';

@Module({
  imports: [CloudinaryModule],
  controllers: [StickersController],
  providers: [StickersService, PrismaService],
  exports: [StickersService],
})
export class StickersModule {}
