import { IsString, IsUrl, IsOptional } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class CreateStickerDto {
  @ApiProperty({ description: 'Name of the sticker' })
  @IsString()
  name: string;

  @ApiProperty({
    description: 'URL to the sticker image/animation',
    required: false,
  })
  @IsUrl()
  @IsOptional()
  url?: string;

  @ApiProperty({
    description: 'Category of the sticker (e.g., Emotions, Animals)',
  })
  @IsString()
  category: string;
}
