import {
  Controller,
  Get,
  Post,
  Body,
  Param,
  UseGuards,
  UseInterceptors,
  UploadedFile,
  BadRequestException,
} from '@nestjs/common';
import { StickersService } from './stickers.service';
import { CreateStickerDto } from './dto/create-sticker.dto';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiConsumes,
  ApiExcludeController,
} from '@nestjs/swagger';
import { AuthGuard } from '../auth/guards/auth.guard';
import { FileInterceptor } from '@nestjs/platform-express';
import { CloudinaryService } from 'src/cloudinary/cloudinary.service';

@ApiExcludeController()
@ApiTags('Stickers')
@Controller('stickers')
@UseGuards(AuthGuard)
export class StickersController {
  constructor(
    private readonly stickersService: StickersService,
    private readonly cloudinaryService: CloudinaryService,
  ) {}

  @Post()
  @ApiOperation({ summary: 'Create a new sticker' })
  @ApiResponse({ status: 201, description: 'Sticker created successfully' })
  @ApiConsumes('multipart/form-data')
  @UseInterceptors(FileInterceptor('file'))
  async create(
    @Body() createStickerDto: CreateStickerDto,
    @UploadedFile() file: Express.Multer.File,
  ) {
    if (!file) {
      throw new BadRequestException('Sticker file is required');
    }

    // Upload the sticker image to Cloudinary
    const url = await this.cloudinaryService.uploadImage(file, {
      folder: 'stickers',
    });

    // Create the sticker with the Cloudinary URL
    return this.stickersService.create({
      ...createStickerDto,
      url,
    } as CreateStickerDto & { url: string });
  }

  @Get()
  @ApiOperation({ summary: 'Get all stickers' })
  findAll() {
    return this.stickersService.findAll();
  }

  @Get('category/:category')
  @ApiOperation({ summary: 'Get stickers by category' })
  findByCategory(@Param('category') category: string) {
    return this.stickersService.findByCategory(category);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get a specific sticker' })
  findOne(@Param('id') id: string) {
    return this.stickersService.findOne(id);
  }
}
