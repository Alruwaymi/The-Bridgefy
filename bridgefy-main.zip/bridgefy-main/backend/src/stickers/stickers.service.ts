import { Injectable, BadRequestException } from '@nestjs/common';

import { CreateStickerDto } from './dto/create-sticker.dto';
import { PrismaService } from 'src/common/prisma.service';

@Injectable()
export class StickersService {
  constructor(private prisma: PrismaService) {}

  async create(createStickerDto: CreateStickerDto & { url: string }) {
    if (!createStickerDto.url) {
      throw new BadRequestException('Sticker URL is required');
    }

    return this.prisma.sticker.create({
      data: createStickerDto,
    });
  }

  async findAll() {
    return this.prisma.sticker.findMany({
      orderBy: {
        category: 'asc',
      },
    });
  }

  async findByCategory(category: string) {
    return this.prisma.sticker.findMany({
      where: {
        category,
      },
    });
  }

  async findOne(id: string) {
    return this.prisma.sticker.findUnique({
      where: { id },
    });
  }
}
