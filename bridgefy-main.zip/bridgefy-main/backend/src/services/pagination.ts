interface PaginationQuery {
  skip: number;
  take: number;
}

export interface PaginationResponse<T> {
  list: T[];
  pagination: {
    page: number;
    pageSize: number;
    total: number;
    totalPages: number;
    hasMore: boolean;
  };
}

interface PaginationParams<T> {
  data: T[];
  page: number;
  pageSize: number;
  total: number;
}

// use at query
export const paginationQuery = (
  page: number = 1,
  pageSize: number = 10,
): PaginationQuery => {
  return {
    skip: (page - 1) * pageSize,
    take: pageSize,
  };
};

// use at response
export const paginationResponse = <T>({
  data,
  page,
  pageSize,
  total,
}: PaginationParams<T>): PaginationResponse<T> => {
  const totalPages = Math.ceil(total / pageSize);

  return {
    list: data,
    pagination: {
      page,
      pageSize,
      total,
      totalPages,
      hasMore: page < totalPages,
    },
  };
};
