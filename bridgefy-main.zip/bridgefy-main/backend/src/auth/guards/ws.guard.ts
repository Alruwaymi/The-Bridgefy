import { CanActivate, ExecutionContext, Injectable } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { Socket } from 'socket.io';
import { Observable } from 'rxjs';

@Injectable()
export class WsGuard implements CanActivate {
  constructor(private jwtService: JwtService) {}

  canActivate(
    context: ExecutionContext,
  ): boolean | Promise<boolean> | Observable<boolean> {
    if (context.getType() !== 'ws') {
      return true;
    }

    const client: Socket = context.switchToWs().getClient();
    return WsGuard.validateToken(client, this.jwtService);
  }

  static async validateToken(client: Socket, jwtService: JwtService) {
    // Try to get token from auth first
    let token = client.handshake?.auth?.token;

    // If no token in auth, try headers;
    if (!token) {
      token = client.handshake?.headers?.authorization?.split(' ')[1];
    }

    if (!token) {
      return false;
    }

    try {
      const payload = await jwtService.verifyAsync(token);
      if (!payload.userId) {
        return false;
      }
      client.data.userId = payload.userId;
      return true;
    } catch {
      return false;
    }
  }
}
