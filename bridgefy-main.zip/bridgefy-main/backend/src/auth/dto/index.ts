import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  IsEmail,
  IsEnum,
  IsNotEmpty,
  IsOptional,
  IsString,
  Matches,
  MinLength,
} from 'class-validator';

export class SignupDto {
  @ApiProperty({ example: 'John' })
  @IsString()
  @IsNotEmpty()
  firstName: string;

  @ApiProperty({ example: 'Doe' })
  @IsString()
  @IsNotEmpty()
  lastName: string;

  @ApiProperty({
    example: 'deaf',
    enum: ['deaf', 'hearing'],
    description: 'User hearing status',
  })
  @IsEnum(['deaf', 'hearing'])
  @IsNotEmpty()
  status: 'deaf' | 'hearing';

  @ApiProperty({
    example: 'text',
    enum: ['text', 'sticker'],
    description: 'Preferred translation method',
  })
  @IsEnum(['text', 'sticker'])
  @IsNotEmpty()
  translationMethod: 'text' | 'sticker';

  @ApiProperty({
    example: 'john.doe@example.com',
    description: 'Email must end with @gmail.com',
  })
  @IsString()
  @IsEmail()
  @IsNotEmpty()
  @Matches(/@gmail\.com$/)
  email: string;

  @ApiProperty({ example: 'password123', minLength: 6 })
  @IsString()
  @MinLength(6)
  password: string;

  @ApiPropertyOptional({
    description: 'Profile image URL',
  })
  @IsString()
  @IsOptional()
  profileImage?: string;
}

export class LoginDto {
  @ApiProperty({ example: 'amr@gmail.com' })
  @IsString()
  @IsNotEmpty()
  email: string;

  @ApiProperty({ example: 'password123' })
  @IsString()
  @IsNotEmpty()
  password: string;
}

export class ForgotPasswordDto {
  @ApiProperty({ example: 'john.doe@example.com' })
  @IsString()
  @IsEmail()
  @IsNotEmpty()
  email: string;
}

export class ResetPasswordDto {
  @ApiProperty({ example: 'john.doe@example.com' })
  @IsString()
  @IsEmail()
  @IsNotEmpty()
  email: string;

  @ApiProperty({ example: '123456' })
  @IsString()
  @IsNotEmpty()
  code: string;

  @ApiProperty({ example: 'newpassword123', minLength: 6 })
  @IsString()
  @MinLength(6)
  newPassword: string;
}
