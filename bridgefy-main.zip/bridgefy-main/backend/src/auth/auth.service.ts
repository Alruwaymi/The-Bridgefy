import {
  Injectable,
  UnauthorizedException,
  ConflictException,
} from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { PrismaService } from '../common/prisma.service';
import * as bcrypt from 'bcrypt';
import { EmailService } from '../email/email.service';
import { ConfigService } from '@nestjs/config';
import { LoginDto, SignupDto } from './dto';
import { UserEntity } from 'src/users/entity/user.entity';

@Injectable()
export class AuthService {
  constructor(
    private prisma: PrismaService,
    private jwtService: JwtService,
    private emailService: EmailService,
    private configService: ConfigService,
  ) {}

  generateRandomAvatar(email: string) {
    return `https://avatar.iran.liara.run/public/girl?username=${email}`;
  }

  async signup(signupDto: SignupDto) {
    const {
      firstName,
      lastName,
      email,
      password,
      status,
      translationMethod,
      profileImage,
    } = signupDto;
    const userExists = await this.prisma.user.findFirst({
      where: {
        email,
      },
    });

    if (userExists) {
      throw new ConflictException(
        'Username, email or phone number already exists',
      );
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const generatedAvatar = this.generateRandomAvatar(email);
    const user = await this.prisma.user.create({
      data: {
        firstName,
        lastName,
        status,
        translationMethod,
        email,
        password: hashedPassword,
        profileImage: profileImage || generatedAvatar,
      },
    });

    const token = await this.generateToken(user.id);

    return {
      user: new UserEntity(user),
      token,
    };
  }

  async login(loginDto: LoginDto) {
    const { email, password } = loginDto;
    const user = await this.prisma.user.findFirst({
      where: {
        email,
      },
    });

    if (!user) {
      throw new UnauthorizedException('Invalid credentials');
    }

    const isPasswordValid = await bcrypt.compare(password, user.password);

    if (!isPasswordValid) {
      throw new UnauthorizedException('Invalid credentials');
    }

    const token = await this.generateToken(user.id);

    return {
      user: new UserEntity(user),
      token,
    };
  }

  async forgotPassword(email: string) {
    const user = await this.prisma.user.findUnique({
      where: { email },
    });

    if (!user) {
      throw new UnauthorizedException('Invalid email address');
    }

    const resetCode = Math.random().toString(36).substring(2, 8).toUpperCase();
    const resetExpires = new Date(Date.now() + 3600000); // 1 hour from now

    await this.prisma.user.update({
      where: { id: user.id },
      data: {
        resetPasswordCode: resetCode,
        resetPasswordExpires: resetExpires,
      },
    });

    await this.emailService.sendResetPassordCode(user.email, {
      name: user.firstName + ' ' + user.lastName,
      resetCode,
    });

    return { message: 'Password reset code sent to your email' };
  }

  async resetPassword(email: string, code: string, newPassword: string) {
    const user = await this.prisma.user.findFirst({
      where: {
        email,
        resetPasswordCode: code,
        resetPasswordExpires: {
          gt: new Date(),
        },
      },
    });

    if (!user) {
      throw new UnauthorizedException('Invalid or expired reset code');
    }

    const hashedPassword = await bcrypt.hash(newPassword, 10);

    await this.prisma.user.update({
      where: { id: user.id },
      data: {
        password: hashedPassword,
        resetPasswordCode: null,
        resetPasswordExpires: null,
      },
    });

    return { message: 'Password has been reset successfully' };
  }

  private async generateToken(userId: string) {
    return this.jwtService.signAsync({ userId });
  }
}
