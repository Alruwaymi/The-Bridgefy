import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsNumber, IsOptional, IsString, Min } from 'class-validator';
import { Type } from 'class-transformer';
import { User } from '@prisma/client';
import { PaginationDto } from 'src/common/dto/pagination.dto';

export class ParticipantDto {
  @ApiProperty()
  id: string;

  @ApiProperty()
  username: string;

  @ApiProperty({ required: false })
  profileImage?: string;

  @ApiProperty()
  status: string;

  @ApiProperty()
  isOnline: boolean;

  @ApiProperty()
  lastSeen: Date;
}

export class MessagePreviewDto {
  @ApiProperty()
  id: string;

  @ApiProperty()
  content: string;

  @ApiProperty()
  createdAt: Date;

  @ApiProperty()
  type: string;
}

export class MessageDto {
  id: string;
  content: string;
  type: string;
  createdAt: Date;
  isRead: boolean;
  readAt?: Date;
  senderId: string;
  sender: User;
  roomId: string;
  fromMe: boolean;
}

export class RoomPreviewDto {
  @ApiProperty()
  id: string;

  @ApiProperty()
  name: string;

  @ApiProperty()
  image: string;

  @ApiProperty()
  lastSeen: Date;

  @ApiProperty({ type: MessagePreviewDto, required: false })
  lastMessage: MessagePreviewDto;

  @ApiProperty()
  unreadMessagesCount: number;

  @ApiProperty()
  receiverId: string;
}

export class RoomDetailDto {
  @ApiProperty({
    example: 'room-id-1',
  })
  id: string;

  @ApiProperty({
    example: 'Room 1',
  })
  name: string;

  @ApiProperty({
    example: 'image.jpg',
  })
  image: string;

  @ApiProperty({
    example: '2022-01-01T12:00:00.000Z',
  })
  lastSeen: Date;

  @ApiProperty({
    type: [MessageDto],
    example: [
      {
        id: 'message-id-1',
        content: 'Hello, world!',
        type: 'text',
        createdAt: '2022-01-01T12:00:00.000Z',
        isRead: true,
        readAt: '2022-01-01T12:00:00.000Z',
        senderId: 'user-id-1',
        fromMe: true,
      },
    ],
  })
  messages: MessageDto[];
}

export class GetRoomsQuery {
  @ApiPropertyOptional({
    example: 1,
    description: 'Page number (starts from 1)',
    default: 1,
  })
  @IsOptional()
  @IsNumber()
  @Min(1)
  @Type(() => Number)
  page?: number = 1;

  @ApiPropertyOptional({
    example: 10,
    description: 'Number of items per page',
    default: 10,
  })
  @IsOptional()
  @IsNumber()
  @Min(1)
  @Type(() => Number)
  pageSize?: number = 10;

  @ApiPropertyOptional({
    example: 'ahmed alaa',
  })
  @IsOptional()
  @IsString()
  search?: string = '';
}

export class PaginatedRoomsResponseDto {
  @ApiProperty({ type: [RoomPreviewDto] })
  list: RoomPreviewDto[];

  @ApiProperty({ type: PaginationDto })
  pagination: PaginationDto;
}

export class PaginatedMessagesResponseDto {
  @ApiProperty({
    type: [MessageDto],
    example: [
      {
        id: 'message-id-1',
        content: 'Hello, world!',
        type: 'text',
        createdAt: '2022-01-01T12:00:00.000Z',
        isRead: true,
        readAt: '2022-01-01T12:00:00.000Z',
        senderId: 'user-id-1',
        fromMe: true,
      },
    ],
  })
  list: MessageDto[];
  @ApiProperty({
    type: PaginationDto,
    example: {
      page: 1,
      pageSize: 10,
      total: 100,
      totalPages: 10,
      hasMore: true,
    },
  })
  pagination: PaginationDto;
}
