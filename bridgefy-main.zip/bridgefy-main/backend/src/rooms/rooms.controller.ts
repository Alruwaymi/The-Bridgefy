import { CacheInterceptor } from '@nestjs/cache-manager';
import {
  Body,
  Controller,
  Get,
  Param,
  Patch,
  Post,
  Query,
  UseGuards,
  UseInterceptors,
} from '@nestjs/common';
import {
  ApiBearerAuth,
  ApiOperation,
  ApiResponse,
  ApiTags,
} from '@nestjs/swagger';
import { FinAllQuery } from 'src/common/dto/findAll.dto';
import { GetUser } from 'src/decorators/getUser';
import { GetMessagesDto } from 'src/messages/dto';
import { MessagesService } from 'src/messages/messages.service';
import { ParseMongoIdPipe } from 'src/pipes/parse-mongo-id.pipe';
import { AuthGuard } from '../auth/guards/auth.guard';
import {
  PaginatedMessagesResponseDto,
  PaginatedRoomsResponseDto,
  RoomPreviewDto,
} from './dto/room.dto';
import { RoomsService } from './rooms.service';
import { CreateRoomDto } from './dto/create-room.dto';

@ApiTags('Rooms')
@ApiBearerAuth()
// @UseInterceptors(CacheInterceptor)
@Controller('rooms')
@UseGuards(AuthGuard)
export class RoomsController {
  constructor(
    private readonly roomsService: RoomsService,
    private readonly messagesService: MessagesService,
  ) {}

  @Get()
  @ApiOperation({ summary: 'Get all rooms for current user' })
  @ApiResponse({ status: 200, type: PaginatedRoomsResponseDto })
  getRoomPreviews(@GetUser('id') userId: string, @Query() query: FinAllQuery) {
    return this.roomsService.getRoomsList({ userId, query });
  }

  @Get(':roomId/messages')
  @ApiOperation({ summary: 'Get all messages for Room' })
  @ApiResponse({
    status: 200,
    description: 'Returns paginated list of messages',
    type: [PaginatedMessagesResponseDto],
  })
  async getRoomMessages(
    @Param('roomId', ParseMongoIdPipe) roomId: string,
    @GetUser('id') userId: string,
    @Query() query: GetMessagesDto,
  ) {
    return this.messagesService.getRoomMessages({
      query,
      roomId,
      userId,
    });
  }

  @Post()
  @ApiOperation({ summary: 'Create new room' })
  @ApiResponse({ status: 200, type: RoomPreviewDto })
  createRoomPreviews(
    @GetUser('id') userId: string,
    @Body() createRoomDto: CreateRoomDto,
  ) {
    return this.roomsService.create({ userId, createRoomDto });
  }

  @Patch(':roomId/mark-as-read')
  @ApiOperation({ summary: 'Mark all messages in room as read by roomId' })
  @ApiResponse({
    status: 200,
    description: 'Messages marked as read',
    example: { message: 'Messages marked as read' },
  })
  async markRoomMessagesAsRead(
    @Param('roomId', ParseMongoIdPipe) roomId: string,
    @GetUser('id') userId: string,
  ) {
    return this.messagesService.markRoomMessagesAsRead({
      roomId,
      userId,
    });
  }
}
