import { Injectable } from '@nestjs/common';
import { Prisma } from '@prisma/client';
import { PrismaService } from '../common/prisma.service';
import { CreateRoomDto } from './dto/create-room.dto';
import { GetRoomsQuery, PaginatedRoomsResponseDto } from './dto/room.dto';
import { paginationQuery, paginationResponse } from 'src/services/pagination';

@Injectable()
export class RoomsService {
  constructor(private prisma: PrismaService) {}

  async getRoomsList({
    userId,
    query,
  }: {
    userId: string;
    query: GetRoomsQuery;
  }): Promise<PaginatedRoomsResponseDto> {
    try {
      const { page = 1, pageSize = 10, search } = query;

      const currentUser = await this.prisma.user.findUnique({
        where: {
          id: userId,
        },
        include: {
          rooms: true,
        },
      });

      const roomIds = currentUser.rooms.map((room) => room.id);

      const whereSearchCondition = search
        ? {
            OR: [
              {
                participants: {
                  some: {
                    OR: [
                      {
                        firstName: {
                          contains: search,
                          mode: 'insensitive',
                        } as Prisma.StringFilter,
                      },
                      {
                        lastName: {
                          contains: search,
                          mode: 'insensitive',
                        } as Prisma.StringFilter,
                      },
                      {
                        email: {
                          contains: search,
                          mode: 'insensitive',
                        } as Prisma.StringFilter,
                      },
                    ],
                  },
                },
              },
              {
                lastMessage: {
                  content: {
                    contains: search,
                    mode: 'insensitive',
                  } as Prisma.StringFilter,
                },
              },
            ],
          }
        : {};

      const where = {
        id: {
          in: roomIds,
        },
        ...whereSearchCondition,
      };

      const [rooms, total] = await this.prisma.$transaction([
        this.prisma.room.findMany({
          where,
          orderBy: {
            lastMessage: {
              createdAt: 'desc',
            },
          },
          include: {
            participants: true,
            lastMessage: {
              select: {
                id: true,
                content: true,
                type: true,
                createdAt: true,
                isRead: true,
                readAt: true,
                senderId: true,
              },
            },
          },
          ...paginationQuery(page, pageSize),
        }),
        this.prisma.room.count({
          where,
        }),
      ]);

      const unreadMessages = await this.prisma.message.findMany({
        where: {
          roomId: {
            in: rooms.map((c) => c.id),
          },
          isRead: false,
          NOT: {
            senderId: userId,
          },
        },
        select: {
          roomId: true,
        },
      });

      const roomPreviews = this.formatRoomsResponse({
        rooms,
        unreadMessages,
        userId,
      });

      return paginationResponse({
        data: roomPreviews,
        page,
        total,
        pageSize,
      });
    } catch (error) {
      throw new Error(error);
    }
  }

  async create({ createRoomDto, userId }) {
    const { receiverId } = createRoomDto;
    const existingRoom = await this.prisma.room.findFirst({
      where: {
        participants: {
          every: {
            id: {
              in: [userId, receiverId],
            },
          },
        },
      },
      include: {
        participants: true,
      },
    });

    if (existingRoom) {
      return this.formatSingleRoomResponse({ room: existingRoom, userId });
    }

    const newRoom = await this.prisma.room.create({
      data: {
        participants: {
          connect: [userId, receiverId].map((id) => ({ id })),
        },
        lastSeen: new Date(),
      },
      include: {
        participants: true,
      },
    });

    return this.formatSingleRoomResponse({ room: newRoom, userId });
  }

  formatSingleRoomResponse({ room, userId }) {
    const participants = room.participants.filter((p) => p.id !== userId);
    const {
      firstName,
      lastName,
      profileImage,
      lastSeen,
      id: receiverId,
    } = participants[0];
    room.name = `${firstName} ${lastName}`;
    room.image = profileImage;
    room.lastSeen = lastSeen;
    room.receiverId = receiverId;
    if (room.lastMessage) {
      room.lastMessage = {
        ...room.lastMessage,
        isRead:
          room.lastMessage.senderId === userId ? true : room.lastMessage.isRead,
        fromMe: room.lastMessage.senderId === userId,
      };
    }
    delete room.participants;
    delete room.lastMessageId;
    return room;
  }

  formatRoomsResponse({
    rooms,
    unreadMessages,
    userId,
  }: {
    rooms: any;
    unreadMessages: any;
    userId: string;
  }) {
    try {
      rooms.forEach((room) => {
        room.unreadMessagesCount = unreadMessages.filter(
          (m) => m.roomId === room.id,
        ).length;
      });

      const roomPreviews = rooms.map((room) => {
        return this.formatSingleRoomResponse({
          room,
          userId,
        });
      });
      return roomPreviews;
    } catch (error) {
      throw new Error(error);
    }
  }
}
