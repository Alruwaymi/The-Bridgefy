import { Injectable } from '@nestjs/common';
import { v2 as cloudinary } from 'cloudinary';
import * as fs from 'fs';
import { ConfigService } from '@nestjs/config';
import { UploadApiResponse, UploadApiErrorResponse } from 'cloudinary';
import { Readable } from 'stream';

interface UploadOptions {
  folder?: string;
  quality?: number;
  width?: number;
  height?: number;
  crop?: string;
  format?: string;
}

interface DeleteOptions {
  type?: string;
  resource_type?: string;
}

@Injectable()
export class CloudinaryService {
  constructor(private configService: ConfigService) {
    cloudinary.config({
      cloud_name: this.configService.get('cloudinary.cloudName'),
      api_key: this.configService.get('cloudinary.apiKey'),
      api_secret: this.configService.get('cloudinary.apiSecret'),
    });
  }

  async uploadImage(
    file: Express.Multer.File,
    options: UploadOptions = {},
  ): Promise<string> {
    const {
      folder = 'uploads',
      quality = 90,
      width = 700,
      height = 700,
      crop = 'fill',
      format = 'jpeg',
    } = options;

    if (!file) {
      throw new Error('No file provided');
    }

    return new Promise((resolve, reject) => {
      const uploadStream = cloudinary.uploader.upload_stream(
        {
          folder,
          quality,
          width,
          height,
          crop,
          format,
        },
        (error, result) => {
          if (error) return reject(error);
          resolve(result.secure_url);
        },
      );

      // If we have a buffer, use it directly
      if (file.buffer) {
        const readable = new Readable();
        readable._read = () => {}; // _read is required but you can noop it
        readable.push(file.buffer);
        readable.push(null);
        readable.pipe(uploadStream);
      }
      // If we have a path, create a read stream from the file
      else if (file.path) {
        fs.createReadStream(file.path)
          .pipe(uploadStream)
          .on('end', () => {
            // Clean up the temporary file if it exists
            fs.unlink(file.path, (err) => {
              if (err) console.error('Error deleting temporary file:', err);
            });
          });
      } else {
        reject(new Error('Invalid file format'));
      }
    });
  }

  async uploadMultipleImages(
    files: Express.Multer.File[],
    options: UploadOptions = {},
  ): Promise<string[]> {
    return Promise.all(files.map((file) => this.uploadImage(file, options)));
  }

  async uploadBuffer(
    buffer: Buffer | ArrayBuffer,
    options: UploadOptions = {},
  ): Promise<string> {
    const {
      folder = 'uploads',
      quality = 90,
      width = 700,
      height = 700,
      crop = 'fill',
      format = 'jpeg',
    } = options;

    if (!buffer) {
      throw new Error('No buffer provided');
    }

    // Convert ArrayBuffer to Buffer if needed
    const bufferData =
      buffer instanceof ArrayBuffer ? Buffer.from(buffer) : buffer;

    return new Promise((resolve, reject) => {
      const uploadStream = cloudinary.uploader.upload_stream(
        {
          folder,
          quality,
          width,
          height,
          crop,
          format,
        },
        (error, result) => {
          if (error) return reject(error);
          resolve(result.secure_url);
        },
      );

      const readable = new Readable();
      readable._read = () => {}; // _read is required but you can noop it
      readable.push(bufferData);
      readable.push(null);
      readable.pipe(uploadStream);
    });
  }

  async uploadBase64Image(
    base64String: string,
    options: UploadOptions = {},
  ): Promise<string> {
    const {
      folder = 'uploads',
      quality = 90,
      width = 700,
      height = 700,
      crop = 'fill',
      format = 'jpeg',
    } = options;

    if (!base64String || !base64String.startsWith('data:')) {
      throw new Error('Invalid base64 image string');
    }

    return new Promise((resolve, reject) => {
      cloudinary.uploader.upload(
        base64String,
        {
          folder,
          quality,
          width,
          height,
          crop,
          format,
        },
        (error: UploadApiErrorResponse, result: UploadApiResponse) => {
          if (error) return reject(error);
          resolve(result.secure_url);
        },
      );
    });
  }

  getImagePublicId(imageUrl: string): string {
    const splitUrl = imageUrl.split('/');
    const filename = splitUrl[splitUrl.length - 1];
    return filename.split('.')[0];
  }

  async deleteImage(
    imageUrl: string,
    options: DeleteOptions = {},
  ): Promise<UploadApiResponse | UploadApiErrorResponse> {
    const { type = 'upload', resource_type = 'image' } = options;
    const publicId = this.getImagePublicId(imageUrl);
    return new Promise((resolve, reject) => {
      cloudinary.uploader
        .destroy(publicId, { type, resource_type })
        .then((result) => resolve(result))
        .catch((error) => reject(error));
    });
  }

  async deleteMultipleImages(
    imageUrls: string[],
    options: DeleteOptions = {},
  ): Promise<(UploadApiResponse | UploadApiErrorResponse)[]> {
    return Promise.all(imageUrls.map((url) => this.deleteImage(url, options)));
  }
}
