import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import * as ejs from 'ejs';
import * as nodemailer from 'nodemailer';
import * as path from 'path';

@Injectable()
export class EmailService {
  private transporter: nodemailer.Transporter | null = null;
  private readonly logger = new Logger(EmailService.name);

  constructor(private configService: ConfigService) {
    const emailService = this.configService.get('email.service');
    const emailUser = this.configService.get('email.user');
    const emailPassword = this.configService.get('email.password');
    const emailPort = this.configService.get('email.port');
    if (emailService && emailUser && emailPassword) {
      this.transporter = nodemailer.createTransport({
        service: emailService,
        port: emailPort,
        secure: true,
        auth: {
          user: emailUser,
          pass: emailPassword,
        },
      });
    } else {
      this.logger.warn(
        'Email configuration not provided. Email service will be disabled.',
      );
    }
  }

  private async renderTemplate(
    templateName: string,
    data: any,
  ): Promise<string> {
    const templatePath = path.join(
      process.cwd(), // like @ at nextjs (root path)
      'src/email/templates',
      `${templateName}.ejs`,
    );
    return ejs.renderFile(templatePath, data);
  }

  private async sendMail(options: nodemailer.SendMailOptions) {
    if (!this.transporter) {
      this.logger.warn('Email service is disabled. Skipping email send.');
      return;
    }

    try {
      await this.transporter.sendMail({
        ...options,
        from: this.configService.get('email.from') || 'noreply@example.com',
      });
    } catch (error) {
      this.logger.error(`Failed to send email: ${error.message}`);
    }
  }

  async sendResetPassordCode(email: string, data: any) {
    const html = await this.renderTemplate('resetCode', data);
    await this.sendMail({
      to: email,
      subject: 'Password reset code',
      html,
    });
  }
}
