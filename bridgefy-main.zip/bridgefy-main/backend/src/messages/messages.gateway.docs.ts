import { Controller, Post } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBody, ApiResponse } from '@nestjs/swagger';
import { MessageType } from './dto/create-message.dto';

@ApiTags('WebSocket Events')
@Controller('ws-docs')
export class WebSocketDocsController {
  @Post('send-message')
  @ApiOperation({
    summary: 'Send a new message (WebSocket Event)',
    description: 'Event name: "send-message" , Emit: when send new message ',
  })
  @ApiBody({
    schema: {
      type: 'object',
      required: ['receiverId', 'content', 'type'],
      properties: {
        receiverId: { type: 'string', description: 'ID of message receiver' },
        content: { type: 'string', description: 'Message content' },
        type: {
          type: 'string',
          enum: Object.values(MessageType),
          description: 'Type of message',
        },
      },
    },
  })
  @ApiResponse({
    status: 200,
    description: 'Message sent successfully, event new-message emitted',
  })
  sendMessage() {
    return {
      message:
        'This is a WebSocket event documentation. Use Socket.IO to emit this event.',
    };
  }

  @Post('mark-message-read')
  @ApiOperation({
    summary: 'Mark a single message as read (WebSocket Event)',
    description:
      'Event name: "mark-message-read" ,Emit: when get new message with fromMe:false and message room is open',
  })
  @ApiBody({
    schema: {
      type: 'object',
      required: ['messageId'],
      properties: {
        messageId: {
          type: 'string',
          description: 'ID of message to mark as read',
        },
      },
    },
  })
  @ApiResponse({
    status: 200,
    description: 'Message marked as read successfully',
  })
  markMessageAsRead() {
    return {
      message:
        'This is a WebSocket event documentation. Use Socket.IO to emit this event.',
    };
  }

  @Post('ws-events')
  @ApiOperation({
    summary: 'WebSocket Events - Client Side Implementation',
    description: `
    To connect to WebSocket:
    
    Option 1 - Using auth:
    const socket = io('YOUR_SERVER_URL/v1', {
      auth: { token }
    });

    Option 2 - Using headers:
    const socket = io('YOUR_SERVER_URL/v1', {
      extraHeaders: {
        Authorization: 'Bearer YOUR_TOKEN'
      }
    });

    Events you can listen to:
    - new-message: Emitted when a new message is received
    - message-read: Emitted when a message is marked as read
    - notification: Emitted for message notifications
    - online-users: Emitted when users' online status changes
    - error: Emitted when an error occurs
    `,
  })
  wsImplementation() {
    return {
      message:
        'This is documentation for WebSocket implementation. See the description for details.',
    };
  }
}
