import {
  Body,
  Controller,
  Param,
  Patch,
  Post,
  Req,
  UseGuards,
} from '@nestjs/common';
import {
  ApiBearerAuth,
  ApiExcludeController,
  ApiOperation,
  ApiResponse,
  ApiTags,
} from '@nestjs/swagger';
import { AuthGuard } from 'src/auth/guards/auth.guard';
import { ParseMongoIdPipe } from 'src/pipes/parse-mongo-id.pipe';
import { CreateMessageDto } from './dto/create-message.dto';
import { MessagesService } from './messages.service';

@ApiTags('Messages')
@ApiBearerAuth()
@ApiExcludeController()
@Controller('messages')
@UseGuards(AuthGuard)
export class MessagesController {
  constructor(private readonly messagesService: MessagesService) {}

  @Post()
  @ApiOperation({ summary: 'Create a new message' })
  @ApiResponse({ status: 201, description: 'Message created successfully' })
  async create(@Body() createMessageDto: CreateMessageDto, @Req() req) {
    return this.messagesService.sendMessage(createMessageDto, req.user.id);
  }

  @Patch(':messageId/mark-as-read')
  @ApiOperation({ summary: 'Mark single message as read' })
  @ApiResponse({ status: 200, description: 'Message marked as read' })
  async markMessageAsRead(
    @Param('messageId', ParseMongoIdPipe) messageId: string,
    @Req() req,
  ) {
    return this.messagesService.markMessageAsRead({
      messageId,
      userId: req.user.id,
    });
  }
}
