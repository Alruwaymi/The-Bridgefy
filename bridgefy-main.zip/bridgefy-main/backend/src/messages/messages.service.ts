import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../common/prisma.service';
import { CreateMessageDto } from './dto/create-message.dto';
import { GetMessagesDto } from './dto/get-messages.dto';
import { RoomsService } from 'src/rooms/rooms.service';
import { paginationQuery, paginationResponse } from 'src/services/pagination';
import { FinAllQuery } from 'src/common/dto/findAll.dto';

@Injectable()
export class MessagesService {
  constructor(
    private prisma: PrismaService,
    private roomsService: RoomsService,
  ) {}

  async sendMessage(createMessageDto: CreateMessageDto, userId: string) {
    const { content, type, roomId } = createMessageDto;

    // Create the message
    const newMessage = await this.prisma.message.create({
      data: {
        content,
        type,
        sender: {
          connect: {
            id: userId,
          },
        },
        room: {
          connect: {
            id: roomId,
          },
        },
      },
    });

    await this.prisma.room.update({
      where: { id: roomId },
      data: {
        lastMessage: {
          connect: {
            id: newMessage.id,
          },
        },
      },
    });

    return newMessage;
  }

  async markMessageAsRead({
    messageId,
    userId,
  }: {
    messageId: string;
    userId: string;
  }) {
    const message = await this.prisma.message.findUnique({
      where: { id: messageId },
      include: {
        room: {
          include: {
            participants: true,
          },
        },
      },
    });

    if (!message) {
      throw new NotFoundException('Message not found');
    }

    // Only allow marking as read if the user is not the sender
    if (message.senderId === userId) {
      throw new NotFoundException('Cannot mark your own message as read');
    }

    return this.prisma.message.update({
      where: { id: messageId },
      data: {
        isRead: true,
        readAt: new Date(),
      },
    });
  }

  async markRoomMessagesAsRead({ roomId, userId }) {
    if (!roomId) {
      throw new NotFoundException(
        'room not found or user is not a participant',
      );
    }

    // Mark all unread messages in the room as read where the user is not the sender
    const now = new Date();
    await this.prisma.message.updateMany({
      where: {
        roomId,
        NOT: {
          senderId: userId,
        },
        isRead: false,
      },
      data: {
        isRead: true,
        readAt: now,
      },
    });

    return { message: 'Messages marked as read' };
  }

  async getRoomMessages({
    roomId,
    userId,
    query,
  }: {
    roomId: string;
    userId: string;
    query: FinAllQuery;
  }) {
    const { page = 1, pageSize = 10 } = query;
    const [messages, total] = await this.prisma.$transaction([
      this.prisma.message.findMany({
        where: { roomId },
        orderBy: { createdAt: 'desc' },
        ...paginationQuery(page, pageSize),
        select: {
          id: true,
          content: true,
          type: true,
          createdAt: true,
          isRead: true,
          readAt: true,
          senderId: true,
        },
      }),
      this.prisma.message.count({
        where: { roomId },
      }),
    ]);

    // add fromMe key
    const messagesWithFromMe = messages.map((message) => ({
      ...message,
      fromMe: message.senderId === userId,
    }));

    return paginationResponse({
      data: messagesWithFromMe.reverse(),
      page,
      total,
      pageSize,
    });
  }
}
