import { JwtService } from '@nestjs/jwt';
import {
  OnGatewayConnection,
  OnGatewayDisconnect,
  SubscribeMessage,
  WebSocketGateway,
  WebSocketServer,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import { WsGuard } from 'src/auth/guards/ws.guard';
import { CloudinaryService } from 'src/cloudinary/cloudinary.service';
import { UsersService } from 'src/users/users.service';
import { MessageType } from './dto/create-message.dto';
import { MessagesService } from './messages.service';
import { Message, Room } from '@prisma/client';

@WebSocketGateway({
  cors: {
    origin: '*',
    credentials: true,
  },
  namespace: '/v1',
  transports: ['websocket', 'polling'],
})
export class MessagesGateway
  implements OnGatewayConnection, OnGatewayDisconnect
{
  @WebSocketServer()
  server: Server;

  private userSockets: Map<string, string> = new Map();

  constructor(
    private readonly messagesService: MessagesService,
    private readonly usersService: UsersService,
    private readonly cloudinary: CloudinaryService,
    private readonly jwtService: JwtService,
  ) {}

  async handleConnection(client: Socket) {
    const isValid = await WsGuard.validateToken(client, this.jwtService);
    if (!isValid) {
      client.emit('error', { message: 'Unauthorized access' });
      client.disconnect();
      return;
    }
    const userId = client.data.userId;
    this.userSockets.set(userId, client.id);
    this.server.emit('online-users', Array.from(this.userSockets.keys()));
  }

  handleDisconnect(client: Socket) {
    const userId = client.data.userId;
    if (!userId) {
      return;
    }

    this.userSockets.delete(userId);
    this.server.emit('online-users', Array.from(this.userSockets.keys()));
    this.server.emit('update-user-last-seen', userId);
    this.server.emit('update-conversation-last-seen', userId);
    this.usersService.updateLastSeen(userId);
  }

  //Emit: when user send message
  @SubscribeMessage('send-message')
  async handleMessage(
    client: Socket,
    payload: {
      roomId: string;
      content: any;
      type: MessageType;
      receiverId: string;
    },
  ) {
    try {
      const senderId = client.data.userId as string;

      if (!senderId) {
        this.server.emit('error', {
          error: 'User ID is required',
        });
        return;
      }
      const { roomId, content, type, receiverId } = payload;

      if (!roomId || !content || !type) {
        this.server.emit('error', {
          error: 'Missing required fields',
        });
        return;
      }

      // Handle image upload if needed
      let finalContent = content;
      if (type === 'image') {
        console.log('🚀 ~ file: messages.gateway.ts:92 ~ content:', content);
        finalContent = await this.cloudinary.uploadBase64Image(content, {
          folder: 'chat',
        });
      }

      // Save message
      const message = await this.messagesService.sendMessage(
        {
          content: finalContent,
          type,
          roomId,
        },
        senderId,
      );
      console.log('🚀 ~ file: messages.gateway.ts:90 ~ message:', message);

      // Send to all participants including sender
      this.emitNewMessage({
        allParticipants: [senderId, receiverId],
        message,
      });

      return {
        success: true,
      };
    } catch (error) {
      console.error('Error handling message:', error);
      const errorMessage =
        error instanceof Error ? error.message : 'Failed to process message';
      client.emit('error', { error: errorMessage });
      throw error;
    }
  }

  //Emit: when new mesage received and user is open the message room
  @SubscribeMessage('mark-room-read')
  async handleMarkRoomAsRead(client: Socket, payload: { room: Room }) {
    const { room } = payload;
    try {
      const userId = client.data.userId as string;
      await this.messagesService.markRoomMessagesAsRead({
        roomId: room.id,
        userId,
      });
      const participantIds = room.participantIds.filter((id) => id !== userId);
      for (const participantId of participantIds) {
        this.server.to(this.userSockets.get(participantId)).emit('room-read', {
          roomId: room.id,
        });
      }

      return { success: true };
    } catch (error) {
      const errorMessage =
        error instanceof Error
          ? error.message
          : 'Failed to mark message as read';
      client.emit('error', { error: errorMessage });
    }
  }
  //Emit: when new mesage received and user is open the message room
  @SubscribeMessage('mark-message-read')
  async handleMarkMessageAsRead(client: Socket, payload: { message: Message }) {
    try {
      const userId = client.data.userId as string;
      const { message } = payload;
      await this.messagesService.markMessageAsRead({
        messageId: message.id,
        userId,
      });

      const senderId = message.senderId;
      this.server.to(this.userSockets.get(senderId)).emit('message-read', {
        messageId: message.id,
      });
      return { success: true };
    } catch (error) {
      const errorMessage =
        error instanceof Error
          ? error.message
          : 'Failed to mark message as read';
      client.emit('error', { error: errorMessage });
    }
  }

  emitNewMessage({
    allParticipants,
    message,
  }: {
    allParticipants: string[];
    message: any;
  }) {
    for (const participantId of allParticipants) {
      const participantSocketId = this.userSockets.get(participantId);
      if (participantSocketId) {
        this.server.to(participantSocketId).emit('new-message', {
          ...message,
          fromMe: participantId === message.senderId,
        });
        this.server.to(participantSocketId).emit('new-room-message', {
          ...message,
          fromMe: participantId === message.senderId,
        });
        if (participantId !== message.senderId) {
          this.server
            .to(participantSocketId)
            .emit('notification', { content: message.content });
        }
      }
    }
  }
}
