import { Module } from '@nestjs/common';
import { RoomsModule } from 'src/rooms/rooms.module';
import { CloudinaryService } from '../cloudinary/cloudinary.service';
import { PrismaService } from '../common/prisma.service';
import { UsersModule } from '../users/users.module';
import { MessagesController } from './messages.controller';
import { MessagesGateway } from './messages.gateway';
import { WebSocketDocsController } from './messages.gateway.docs';
import { MessagesService } from './messages.service';

@Module({
  imports: [UsersModule, RoomsModule],
  controllers: [MessagesController, WebSocketDocsController],
  providers: [
    MessagesService,
    MessagesGateway,
    PrismaService,
    CloudinaryService,
  ],
  exports: [MessagesService],
})
export class MessagesModule {}
