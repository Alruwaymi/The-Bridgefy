import { CacheInterceptor } from '@nestjs/cache-manager';
import {
  Body,
  Controller,
  Get,
  Param,
  Patch,
  Query,
  UploadedFile,
  UseGuards,
  UseInterceptors,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import {
  ApiBearerAuth,
  ApiOperation,
  ApiResponse,
  ApiTags,
} from '@nestjs/swagger';
import { User } from '@prisma/client';
import { AuthGuard } from 'src/auth/guards/auth.guard';
import { CloudinaryService } from 'src/cloudinary/cloudinary.service';
import { FinAllQuery } from 'src/common/dto/findAll.dto';
import { GetUser } from 'src/decorators/getUser';
import { ParseMongoIdPipe } from 'src/pipes/parse-mongo-id.pipe';
import { PaginationResponse } from 'src/services/pagination';
import {
  PaginatedUsersResponseDto,
  UpdatePasswordDto,
  UpdateProfileDto,
  UpdateTranslationMethodDto,
} from './dto';
import { UserEntity } from './entity/user.entity';
import { UsersService } from './users.service';

@ApiTags('users')
@ApiBearerAuth()
@Controller('users')
// @UseInterceptors(CacheInterceptor)
@UseGuards(AuthGuard)
export class UsersController {
  constructor(
    private readonly usersService: UsersService,
    private readonly cloudinaryService: CloudinaryService,
  ) {}

  @Get()
  @ApiOperation({ summary: 'Get all users with search capability' })
  @ApiResponse({
    status: 200,
    description: 'Returns list of users',
    type: PaginatedUsersResponseDto,
  })
  async getUsers(
    @GetUser('id') userId: string,
    @Query() query?: FinAllQuery,
  ): Promise<PaginationResponse<UserEntity>> {
    return this.usersService.findAll(query, userId);
  }

  @Get('me')
  @ApiOperation({ summary: 'Get current user profile' })
  @ApiResponse({
    status: 200,
    description: 'Returns current user profile',
    type: UserEntity,
  })
  async getCurrentUser(@GetUser('id') userId: string): Promise<UserEntity> {
    return this.usersService.findById(userId);
  }

  @Patch('update')
  @ApiOperation({
    summary: 'Update current user profile',
    description: 'Update current user profile, Data must be sent in form-data',
  })
  @ApiResponse({
    status: 200,
    description: 'Profile updated successfully',
    type: UserEntity,
  })
  @UseInterceptors(FileInterceptor('profileImage'))
  async updateProfile(
    @GetUser('id') userId: string,
    @Body() updateProfileDto: UpdateProfileDto,
    @UploadedFile() profileImage: Express.Multer.File,
  ) {
    if (
      updateProfileDto?.profileImage &&
      updateProfileDto?.profileImage?.startsWith('data:image')
    ) {
      updateProfileDto.profileImage =
        await this.cloudinaryService.uploadBase64Image(
          updateProfileDto.profileImage,
        );
    }

    if (profileImage) {
      updateProfileDto.profileImage =
        await this.cloudinaryService.uploadImage(profileImage);
    }
    return this.usersService.updateProfile({
      userId,
      updateProfileDto,
    });
  }

  // update translationMethod
  @Patch('update-translation-method')
  @ApiOperation({
    summary: 'Update current user translationMethod',
    description: 'Update current user translationMethod',
  })
  @ApiResponse({
    status: 200,
    description: 'Translation Method updated successfully',
  })
  async updateTranslationMethod(
    @GetUser('id') userId: string,
    @Body() body: UpdateTranslationMethodDto,
  ) {
    return this.usersService.updateTranslationMethod({
      userId,
      translationMethod: body.translationMethod,
    });
  }

  @Patch('change-password')
  @ApiOperation({ summary: 'Change password' })
  @ApiResponse({ status: 200, description: 'Password changed successfully' })
  async changePassword(
    @GetUser('id') userId: string,
    @Body() updatePasswordDto: UpdatePasswordDto,
  ) {
    return this.usersService.updatePassword(userId, updatePasswordDto);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get user by ID' })
  @ApiResponse({ status: 200, description: 'Returns user profile' })
  async getUserById(@Param('id', ParseMongoIdPipe) id: string): Promise<User> {
    return this.usersService.findById(id);
  }
}
