import { ApiProperty } from '@nestjs/swagger';
import { Exclude, Expose } from 'class-transformer';

export class UserEntity {
  @ApiProperty()
  id: string;
  @ApiProperty()
  email: string;
  @ApiProperty()
  firstName: string;
  @ApiProperty()
  lastName: string;
  @ApiProperty()
  profileImage: string;
  @ApiProperty()
  translationMethod: string;
  @ApiProperty()
  status: string;
  @ApiProperty()
  lastSeen: Date;
  @ApiProperty()
  createdAt: Date;
  @ApiProperty()
  updatedAt: Date;

  @ApiProperty()
  @Expose()
  get fullName(): string {
    return `${this.firstName} ${this.lastName}`;
  }

  @Exclude()
  password: string;
  @Exclude()
  resetPasswordCode: string;
  @Exclude()
  resetPasswordExpires: Date;
  @Exclude()
  roomIds: string[];

  constructor(partial: Partial<UserEntity>) {
    Object.assign(this, partial);
  }
}
