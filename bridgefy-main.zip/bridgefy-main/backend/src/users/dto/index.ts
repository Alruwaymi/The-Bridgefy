import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  IsEmail,
  IsEnum,
  IsNotEmpty,
  IsOptional,
  IsString,
  Matches,
  MinLength,
} from 'class-validator';
import { PaginationDto } from 'src/common/dto/pagination.dto';
import { UserEntity } from '../entity/user.entity';

export class UpdateProfileDto {
  @ApiPropertyOptional({
    example: 'John',
  })
  @IsString()
  @IsOptional()
  firstName?: string;

  @ApiPropertyOptional({
    example: 'Doe',
  })
  @IsString()
  @IsOptional()
  lastName?: string;

  @ApiPropertyOptional({
    example: 'amr@gmail.com',
    description: 'Email must end with @gmail.com',
  })
  @IsEmail()
  @IsOptional()
  @Matches(/@gmail\.com$/)
  email?: string;

  @ApiPropertyOptional({
    enum: ['deaf', 'hearing'],
    default: 'deaf',
  })
  @IsEnum(['deaf', 'hearing'])
  @IsOptional()
  status?: 'deaf' | 'hearing';

  @ApiPropertyOptional({
    enum: ['text', 'sticker'],
    default: 'text',
  })
  @IsEnum(['text', 'sticker'])
  @IsOptional()
  translationMethod?: 'text' | 'sticker';

  @ApiPropertyOptional({
    description: 'Profile image URL',
  })
  @IsString()
  @IsOptional()
  profileImage?: string;
}

export class UpdatePasswordDto {
  @ApiProperty({
    example: 'password123',
  })
  @IsString()
  @IsNotEmpty()
  currentPassword: string;

  @ApiProperty({
    example: 'newpassword123',
    minLength: 6,
  })
  @IsString()
  @IsNotEmpty()
  @MinLength(6)
  newPassword: string;
}

export class ChangePasswordDto {
  @ApiPropertyOptional({
    example: 'password123',
    minLength: 6,
  })
  @IsString()
  @IsNotEmpty()
  oldPassword: string;

  @ApiProperty({
    example: 'newpassword123',
    minLength: 6,
  })
  @IsString()
  @MinLength(6)
  newPassword: string;
}

export class UpdateTranslationMethodDto {
  @ApiProperty({
    enum: ['text', 'sticker'],
    default: 'text',
  })
  @IsEnum(['text', 'sticker'])
  translationMethod: 'text' | 'sticker';
}

export class PaginatedUsersResponseDto {
  @ApiProperty({ type: [UserEntity] })
  list: UserEntity[];

  @ApiProperty({ type: PaginationDto })
  pagination: PaginationDto;
}
