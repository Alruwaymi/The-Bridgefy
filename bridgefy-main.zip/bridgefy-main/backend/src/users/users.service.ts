import { Injectable, NotFoundException } from '@nestjs/common';
import { Prisma } from '@prisma/client';
import * as bcrypt from 'bcrypt';
import { FinAllQuery } from 'src/common/dto/findAll.dto';
import { paginationQuery, paginationResponse } from 'src/services/pagination';
import { PrismaService } from '../common/prisma.service';
import {
  PaginatedUsersResponseDto,
  UpdatePasswordDto,
  UpdateProfileDto,
} from './dto';
import { UserEntity } from './entity/user.entity';

@Injectable()
export class UsersService {
  constructor(private prisma: PrismaService) {}

  async findAll(
    query: FinAllQuery,
    userId: string,
  ): Promise<PaginatedUsersResponseDto> {
    const { search, page, pageSize } = query;
    const whereCondition: Prisma.UserWhereInput = search
      ? {
          id: {
            not: userId,
          },
          OR: [
            {
              firstName: {
                contains: search,
                mode: 'insensitive',
              },
            },
            {
              lastName: {
                contains: search,
                mode: 'insensitive',
              },
            },
            {
              email: {
                contains: search,
                mode: 'insensitive',
              },
            },
          ],
        }
      : {
          id: {
            not: userId,
          },
        };

    const [users, count] = await this.prisma.$transaction([
      this.prisma.user.findMany({
        where: whereCondition,
        ...paginationQuery(page, pageSize),
      }),
      this.prisma.user.count({
        where: whereCondition,
      }),
    ]);

    return paginationResponse({
      data: users.map((user) => new UserEntity(user)),
      page,
      total: count,
      pageSize,
    });
  }

  async findById(userId: string) {
    const user = await this.prisma.user.findUnique({
      where: { id: userId },
    });

    if (!user) {
      throw new NotFoundException('User not found');
    }

    return new UserEntity(user);
  }

  async updateProfile({
    userId,
    updateProfileDto,
  }: {
    userId: string;
    updateProfileDto: UpdateProfileDto;
  }) {
    const user = await this.prisma.user.update({
      where: { id: userId },
      data: updateProfileDto,
    });
    return new UserEntity(user);
  }

  async updateTranslationMethod({
    userId,
    translationMethod,
  }: {
    userId: string;
    translationMethod: string;
  }) {
    const user = await this.prisma.user.update({
      where: { id: userId },
      data: { translationMethod },
    });
    return new UserEntity(user);
  }

  async updatePassword(userId: string, updatePasswordDto: UpdatePasswordDto) {
    const user = await this.prisma.user.findUnique({ where: { id: userId } });
    if (!user) {
      throw new NotFoundException('User not found');
    }

    const isPasswordValid = await bcrypt.compare(
      updatePasswordDto.currentPassword,
      user.password,
    );
    if (!isPasswordValid) {
      throw new NotFoundException('Invalid current password');
    }

    const hashedPassword = await bcrypt.hash(updatePasswordDto.newPassword, 10);
    await this.prisma.user.update({
      where: { id: userId },
      data: { password: hashedPassword },
    });

    return { message: 'Password updated successfully' };
  }

  async updateLastSeen(userId: string) {
    return this.prisma.user.update({
      where: { id: userId },
      data: {
        lastSeen: new Date(),
      },
    });
  }
}
