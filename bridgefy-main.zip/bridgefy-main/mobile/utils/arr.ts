// utils/arrayUtils.js

interface UniqueOptions {
  key?: string | null;
  ignoreCase?: boolean;
  compareFunction?: ((a: any, b: any) => boolean) | null;
}

export const uniqueAdvanced = (array: any[], options: UniqueOptions = {}) => {
  if (!Array.isArray(array)) return [];

  const { key = null, ignoreCase = false, compareFunction = null } = options;

  // If a custom compare function is provided
  if (compareFunction) {
    return array.filter(
      (item, index) =>
        array.findIndex((other) => compareFunction(item, other)) === index
    );
  }

  // If we're dealing with objects and a key is provided
  if (key) {
    const seen = new Set();
    return array.filter((item) => {
      const value =
        ignoreCase && typeof item[key] === "string"
          ? item[key].toLowerCase()
          : item[key];
      if (seen.has(value)) {
        return false;
      }
      seen.add(value);
      return true;
    });
  }

  // For primitive values
  if (ignoreCase) {
    const seen = new Set();
    return array.filter((item) => {
      const value = typeof item === "string" ? item.toLowerCase() : item;
      if (seen.has(value)) {
        return false;
      }
      seen.add(value);
      return true;
    });
  }

  // Default case
  return [...new Set(array)];
};
