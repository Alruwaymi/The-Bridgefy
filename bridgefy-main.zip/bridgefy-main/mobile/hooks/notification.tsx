// // hooks/useNotification.ts
// import { useState, useEffect, useRef } from "react";
// import * as Notifications from "expo-notifications";
// import * as Device from "expo-device";
// import Constants from "expo-constants";
// import { Platform, Alert } from "react-native";

// // Set notification handler
// Notifications.setNotificationHandler({
//   handleNotification: async () => ({
//     shouldShowAlert: true,
//     shouldPlaySound: true,
//     shouldSetBadge: true,
//     priority: Notifications.AndroidNotificationPriority.HIGH,
//   }),
// });

// interface NotificationContent {
//   title: string;
//   body: string;
//   data?: object;
// }

// export const useNotification = () => {
//   const [expoPushToken, setExpoPushToken] = useState<string>("");
//   const [notification, setNotification] =
//     useState<Notifications.Notification>();
//   const notificationListener = useRef<Notifications.Subscription>();
//   const responseListener = useRef<Notifications.Subscription>();
//   const [isReady, setIsReady] = useState(false);

//   useEffect(() => {
//     setupNotifications();
//     return () => {
//       if (notificationListener.current) {
//         Notifications.removeNotificationSubscription(
//           notificationListener.current
//         );
//       }
//       if (responseListener.current) {
//         Notifications.removeNotificationSubscription(responseListener.current);
//       }
//     };
//   }, []);

//   const setupNotifications = async () => {
//     try {
//       if (Platform.OS === "android") {
//         await Notifications.setNotificationChannelAsync("default", {
//           name: "Default",
//           importance: Notifications.AndroidImportance.MAX,
//           vibrationPattern: [0, 250, 250, 250],
//           lightColor: "#FF231F7C",
//         });
//       }

//       const token = await registerForPushNotificationsAsync();
//       if (token) {
//         setExpoPushToken(token);
//       }

//       notificationListener.current =
//         Notifications.addNotificationReceivedListener((notification) => {
//           setNotification(notification);
//         });

//       responseListener.current =
//         Notifications.addNotificationResponseReceivedListener((response) => {
//           console.log("Notification tapped:", response);
//         });

//       setIsReady(true);
//     } catch (error) {
//       console.error("Error setting up notifications:", error);
//       Alert.alert("Error", "Failed to setup notifications");
//     }
//   };

//   const sendNotification = async (content: NotificationContent) => {
//     try {
//       if (!isReady) {
//         throw new Error("Notifications not initialized");
//       }

//       const notificationId = await Notifications.scheduleNotificationAsync({
//         content: {
//           title: content.title,
//           body: content.body,
//           data: content.data || {},
//           sound: true,
//           priority: Notifications.AndroidNotificationPriority.HIGH,
//         },
//         trigger: {
//           seconds: 1,
//           channelId: "default",
//         },
//       });

//       console.log("Notification scheduled:", notificationId);
//       return notificationId;
//     } catch (error) {
//       console.error("Error sending notification:", error);
//       throw error;
//     }
//   };

//   return {
//     sendNotification,
//     notification,
//     expoPushToken,
//     isReady,
//   };
// };

// async function registerForPushNotificationsAsync() {
//   let token;

//   if (!Device.isDevice) {
//     Alert.alert("Error", "Must use physical device for Push Notifications");
//     return;
//   }

//   try {
//     const { status: existingStatus } =
//       await Notifications.getPermissionsAsync();
//     let finalStatus = existingStatus;

//     if (existingStatus !== "granted") {
//       const { status } = await Notifications.requestPermissionsAsync();
//       finalStatus = status;
//     }

//     if (finalStatus !== "granted") {
//       throw new Error("Failed to get push token for push notification!");
//     }

//     const projectId =
//       Constants.expoConfig?.extra?.eas?.projectId ||
//       Constants.easConfig?.projectId;

//     if (!projectId) {
//       throw new Error("Project ID not found");
//     }

//     const tokenData = await Notifications.getExpoPushTokenAsync({
//       projectId: projectId,
//     });

//     token = tokenData.data;
//   } catch (error) {
//     console.error("Error getting push token:", error);
//     Alert.alert("Error", "Failed to get push token");
//   }

//   return token;
// }
