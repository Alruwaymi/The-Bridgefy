import { useState, useEffect } from "react";
import * as SecureStore from "expo-secure-store";

// Define the User type
export interface User {
  createdAt: string; // ISO date string
  email: string;
  firstName: string;
  fullName: string;
  id: string;
  lastName: string;
  lastSeen: string;
  profileImage: string;
  status: string;
  translationMethod: string;
  updatedAt: string;
}

interface UseSecureUserResult {
  user: User | null;
  loading: boolean;
  error: Error | null;
  saveUser: (newUser: User) => Promise<void>;
  removeUser: () => Promise<void>;
}

export const useSecureUser = (): UseSecureUserResult => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<Error | null>(null);

  useEffect(() => {
    const fetchUser = async () => {
      try {
        setLoading(true);
        const storedUser = await SecureStore.getItemAsync("user");
        if (storedUser) {
          setUser(JSON.parse(storedUser));
        } else {
          setUser(null);
        }
      } catch (err) {
        console.error("Error fetching user:", err);
        setError(err as Error);
      } finally {
        setLoading(false);
      }
    };

    fetchUser();
  }, []);

  const saveUser = async (newUser: User): Promise<void> => {
    try {
      const userString = JSON.stringify(newUser);
      await SecureStore.setItemAsync("user", userString);
      setUser(newUser); // Update local state
    } catch (err) {
      console.error("Error saving user:", err);
      setError(err as Error);
    }
  };

  const removeUser = async (): Promise<void> => {
    try {
      await SecureStore.deleteItemAsync("user");
      setUser(null); // Reset local state
    } catch (err) {
      console.error("Error removing user:", err);
      setError(err as Error);
    }
  };

  return {
    user,
    loading,
    error,
    saveUser,
    removeUser,
  };
};
