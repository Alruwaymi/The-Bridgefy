import React from "react";

import {
  ActivityIndicator,
  Alert,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  Text,
  TouchableOpacity,
  View,
} from "react-native";

import { Ionicons, MaterialCommunityIcons } from "@expo/vector-icons";

import CustomHeader from "../comp/CustomHeader";
import useStore from "../store/useStore";
import tw from "../tailwind";

const SignUpThirdStepScreen = ({ navigation }: { navigation: any }) => {
  const { updateSignUpData, signUp, loading, signUpData } = useStore();

  const handleSelection = async (method: string) => {
    if (!method) {
      Alert.alert("Error", "Please select a translation method.");
      return;
    }

    // Update the sign-up data with the translation method
    updateSignUpData({ translationMethod: method });

    try {
      // Call the sign-up action to submit all data to the backend
      const res = await signUp();

      // navigation.replace("ProfileUpdate");
    } catch (error: any) {
      // Navigate back to the first sign-up step
      Alert.alert("Sign-Up Failed", error.message, [
        {
          text: "OK",
          onPress: () => navigation.navigate("SignUpFirstStep"),
        },
      ]);
    }
  };

  return (
    <View style={tw`flex-1 bg-white`}>
      <CustomHeader />
      <KeyboardAvoidingView
        style={tw`flex-1`}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
        keyboardVerticalOffset={Platform.OS === "ios" ? 0 : 0}
      >
        <ScrollView
          contentContainerStyle={tw`px-8 pb-8`}
          keyboardShouldPersistTaps="handled"
        >
          {/* User Status Display */}
          {/* <View
            style={tw`flex-row items-center justify-end gap-1 bg-pink2 border w-auto rounded-r-full py-1 pr-2 -ml-10 mt-4`}
          > */}
          <View
            style={tw`flex-row items-center justify-end gap-1  bg-pink2 border w-fit rounded-r-full py-1  pr-2  -ml-10 w-1/3`}
          >
            <Ionicons name="checkmark" size={16} color="black" />
            <Text style={tw`text-sm font-semibold py-2 px-2`}>
              {signUpData.status === "deaf" ? "Deaf" : "Hearing"}
            </Text>
          </View>

          {/* Title */}
          <View
            style={tw`flex-col gap-10 items-center justify-center mb-6 mt-40`}
          >
            <View style={tw`items-center justify-center mb-4`}>
              <View style={tw`px-6 bg-pink1 py-3 border-b-2 border-black`}>
                <Text style={tw`text-sm font-semibold py-2 px-2`}>
                  Choose a Text Translation Method:
                </Text>
              </View>
            </View>

            {/* Option Buttons */}
            <View style={tw`flex-row items-center justify-center gap-4`}>
              <TouchableOpacity
                style={tw`bg-gray-200 py-3 px-8 rounded-xl flex-row items-center border border-gray-300`}
                onPress={() => handleSelection("text")}
                disabled={loading}
              >
                <Ionicons
                  name="document-text-outline"
                  size={20}
                  color="black"
                />
                <Text style={tw`text-black text-base ml-2`}>Text</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={tw`bg-gray-200 py-3 px-6 rounded-xl flex-row items-center border border-gray-300`}
                onPress={() => handleSelection("sticker")}
                disabled={loading}
              >
                <MaterialCommunityIcons
                  name="sticker-circle-outline"
                  size={20}
                  color="black"
                />
                <Text style={tw`text-black text-base ml-2`}>Sticker</Text>
              </TouchableOpacity>
            </View>

            {/* Loading Indicator */}
            {loading && (
              <View style={tw`mt-4`}>
                <ActivityIndicator size="large" color="#000" />
              </View>
            )}
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
};

export default SignUpThirdStepScreen;
