import { View, Text, ScrollView } from "react-native";
import tw from "../tailwind";
import CustomHeader from "../comp/CustomHeader";

export default function AboutScreen() {
  return (
    <ScrollView style={tw`flex-1 bg-white  `}>
      <CustomHeader />
      <View style={tw`px-6`}>
        {/* Header */}
        <Text style={tw`text-3xl font-bold mb-6 text-gray-800`}>
          About The Team
        </Text>

        {/* Main Content */}
        <View style={tw`bg-gray-50 rounded-xl p-6 shadow-md`}>
          <Text style={tw`text-gray-800 text-lg leading-7 mb-4`}>
            The Bridgefy team comprises three members: individuals, namely
            Mohammed Alruwaymi, Fawaz Mufti and Faisal Alahmadi, who are united
            by a shared passion for innovation in the field of technology.
          </Text>

          <Text style={tw`text-gray-800 text-lg leading-7 mb-4`}>
            Drawing upon a range of backgrounds and experiences, the team works
            collaboratively to transform creative ideas into tangible solutions.
            The collaborative nature of the team is evident in their commitment
            to addressing real-world challenges through the utilisation of
            cutting-edge technology, as exemplified by their project "Bridgefy".
          </Text>

          <Text style={tw`text-gray-800 text-lg leading-7`}>
            The team's collective ethos is characterised by a commitment to
            excellence, a dedication to continuous learning, and the pursuit of
            significant and impactful outcomes.
          </Text>
        </View>

        {/* Team Members */}
        <View style={tw`mt-8`}>
          <Text style={tw`text-2xl font-bold mb-4 text-gray-800`}>
            Team Members
          </Text>

          {/* Team Member Cards */}
          <View style={tw`flex-col gap-2`}>
            {/* Mohammed */}
            <View style={tw`bg-gray-50 rounded-lg p-4 shadow-sm`}>
              <Text style={tw`text-xl font-semibold text-gray-800`}>
                Mohammed Alruwaymi
              </Text>
            </View>

            {/* Fawaz */}
            <View style={tw`bg-gray-50 rounded-lg p-4 shadow-sm`}>
              <Text style={tw`text-xl font-semibold text-gray-800`}>
                Fawaz Mufti
              </Text>
            </View>

            {/* Faisal */}
            <View style={tw`bg-gray-50 rounded-lg p-4 shadow-sm`}>
              <Text style={tw`text-xl font-semibold text-gray-800`}>
                Faisal Alahmadi
              </Text>
            </View>
          </View>
        </View>
      </View>
    </ScrollView>
  );
}
