import React, { useCallback, useEffect, useRef, useState } from "react";

import {
  ActivityIndicator,
  FlatList,
  Image,
  SafeAreaView,
  Text,
  View,
} from "react-native";

import * as ImagePicker from "expo-image-picker";

import * as FileSystem from "expo-file-system";
import { Ionicons } from "@expo/vector-icons";
import { RouteProp, useRoute } from "@react-navigation/native";
import { StackNavigationProp } from "@react-navigation/stack";

import ChatHeader from "../comp/ChatHeader/ChatHeader";
import MessageInput from "../comp/messageInput/messageInput";
import SearchMessage from "../comp/searchMessage/searchMessage";
import axiosInstance from "../api/axiosInstance";
import tw from "../tailwind";
import useStore from "../store/useStore";
import { StickersComp } from "../comp/sticker";
import { useChatContext } from "../context/socketContext";
import { convertImageToBase64 } from "../utils/basa64";
import { Message } from "../types/chatType";
import { useSecureUser } from "../hooks/secureUser";
import { allStickers } from "../const/sticker";

// Define types for navigation
type RootStackParamList = {
  MainComponent: undefined;
  ChatScreen: { RoomInfo: User };
};

type ChatScreenNavigationProp = StackNavigationProp<
  RootStackParamList,
  "ChatScreen"
>;

type ChatScreenRouteProp = RouteProp<RootStackParamList, "ChatScreen">;

// Define User type
interface User {
  id: string;
  receiverId: string;
  name: string;
  image: string;
  roomId: string;
  lastSeen: Date;
}

// Define Sticker type
interface Sticker {
  id: number;
  path: any;
  en: string;
  ar: string;
}

const ChatScreen: React.FC = () => {
  const route = useRoute<ChatScreenRouteProp>();
  const { RoomInfo } = route.params;
  const { user } = useSecureUser();

  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState("");
  const flatListRef = useRef<FlatList>(null);

  const [page, setPage] = useState(1);
  const [hasMoreMessages, setHasMoreMessages] = useState(true);
  const [isSendingMessageLoading, setIsSendingMessageLoading] = useState(false);
  const [isLoadingMessages, setIsLoadingMessages] = useState(false);
  const [isStickerPickerVisible, setStickerPickerVisible] = useState(false);
  const [searchModalVisible, setSearchModalVisible] = useState(false);

  const { hasNotification, socket, onlineUsers, socketError } =
    useChatContext();
  console.log("🚀 ~ socketError:", socketError);

  const fetchMessages = async (newPage = 1) => {
    if (isLoadingMessages || !hasMoreMessages) return;

    setIsLoadingMessages(true);

    try {
      const requestUrl = `/rooms/${RoomInfo.id}/messages`;

      const response = await axiosInstance.get(requestUrl, {
        params: { page: newPage, pageSize: 20 },
      });

      console.log("API Response Data:", JSON.stringify(response.data, null, 2));

      // Access the 'data' object in the response
      const responseData = response.data;

      if (responseData.success && responseData.data) {
        const { list, pagination } = responseData.data;

        setMessages((prevMessages) =>
          newPage === 1
            ? list.sort(
                (a: any, b: any) =>
                  new Date(b.createdAt).getTime() -
                  new Date(a.createdAt).getTime()
              )
            : [...prevMessages, ...list].sort(
                (a, b) =>
                  new Date(b.createdAt).getTime() -
                  new Date(a.createdAt).getTime()
              )
        );

        setHasMoreMessages(pagination.hasMore);
        setPage(newPage);
      } else {
        console.error("Unexpected API response structure:", responseData);
      }
    } catch (error) {
      console.error("Error fetching messages:", error);
    } finally {
      setIsLoadingMessages(false);
    }
  };

  const readMarkReadMsgRequst = () => {
    socket?.emit("mark-room-read", { room: RoomInfo });
  };
  console.log("🚀 ~ readMarkReadMsgRequst ~ RoomInfo:", RoomInfo);

  const markSingleMassageRead = (msg: {}) => {
    if (!socket) return;
    const messagePayload = {
      message: msg,
    };
    socket.emit("mark-message-read", messagePayload);
  };
  useEffect(() => {
    fetchMessages();
    readMarkReadMsgRequst();
  }, []);

  useEffect(() => {
    const handleNewMessage = (msg: Message) => {
      setMessages((prevMessages) =>
        [msg, ...prevMessages].sort(
          (a, b) =>
            new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
        )
      );

      if (!msg.fromMe) {
        markSingleMassageRead(msg);
      }
    };

    socket?.on("new-message", handleNewMessage);

    return () => {
      socket?.off("new-message", handleNewMessage);
    };
  }, [socket, RoomInfo.receiverId]);
  useEffect(() => {
    const handleNewMessage = ({ messageId }: { messageId: string }) => {
      setMessages((prevMessages) =>
        prevMessages.map((msg: Message) =>
          msg.id === messageId ? { ...msg, isRead: true } : msg
        )
      );
    };

    socket?.on("message-read", handleNewMessage);

    return () => {
      socket?.off("message-read", handleNewMessage);
    };
  }, [socket, RoomInfo.receiverId]);
  useEffect(() => {
    const handleNewMessage = ({ roomId }: { roomId: string }) => {
      if (RoomInfo.id === roomId) {
        setMessages((prevMessages) =>
          prevMessages.map((msg: Message) => ({ ...msg, isRead: true }))
        );
      }
    };

    socket?.on("room-read", handleNewMessage);

    return () => {
      socket?.off("room-read", handleNewMessage);
    };
  }, [socket, RoomInfo.receiverId]);

  const sendMessage = () => {
    if (inputText.trim() === "" || !socket) return;
    setIsSendingMessageLoading(true);
    const messagePayload = {
      roomId: RoomInfo.id,
      receiverId: RoomInfo.receiverId,
      content: inputText,
      type: "text",
    };
    socket.emit("send-message", messagePayload, () => {
      setIsSendingMessageLoading(false);
    });
    setInputText("");

    flatListRef.current?.scrollToOffset({ offset: 0, animated: true });
  };
  const [processedMessages, setProcessedMessages] = useState<
    (Message | { type: "dateSeparator"; date: string; id: string })[]
  >([]);

  useEffect(() => {
    setProcessedMessages(processMessagesWithDateSeparators(messages));
  }, [messages]);

  const renderItem = ({
    item,
  }: {
    item: Message | { type: "dateSeparator"; date: string; id: string };
  }) => {
    if (item.type === "dateSeparator") {
      return <DateSeparator date={item.date} />;
    }
    return renderMessageItem({ item: item as Message });
  };
  const sendStickerMessage = async (sticker: string) => {
    console.log("sadasdaad", sticker);

    if (!socket) return;
    try {
      setIsSendingMessageLoading(true);

      // Get the asset file path
      // const assetUri = Image.resolveAssetSource(sticker.path).uri;
      console.log("🚀 ~ assetUri:", sticker);

      // Convert to base64
      // const base64 = await convertStickerToBase64(assetUri);

      const messagePayload = {
        roomId: RoomInfo.id,
        receiverId: RoomInfo.receiverId,
        content: sticker,
        type: "sticker",
      };

      socket.emit("send-message", messagePayload, () => {
        setIsSendingMessageLoading(false);
      });

      setStickerPickerVisible(false);
      flatListRef.current?.scrollToOffset({ offset: 0, animated: true });
    } catch (error) {
      console.error("Error sending sticker:", error);
      setIsSendingMessageLoading(false);
    }
  };

  const pickImage = async () => {
    const permissionResult =
      await ImagePicker.requestMediaLibraryPermissionsAsync();

    if (permissionResult.granted === false) {
      alert("Permission to access camera roll is required!");
      return;
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: false,
      quality: 0.2,
    });

    if (
      !result.canceled &&
      result.assets &&
      result.assets.length > 0 &&
      socket
    ) {
      try {
        setIsSendingMessageLoading(true);

        const base64 = await convertImageToBase64(result.assets[0].uri);

        const messagePayload = {
          roomId: RoomInfo.id,
          receiverId: RoomInfo.receiverId,
          content: base64,
          type: "image",
        };

        socket.emit("send-message", messagePayload, () => {
          setIsSendingMessageLoading(false);
        });

        flatListRef.current?.scrollToOffset({ offset: 0, animated: true });
      } catch (error) {
        console.error("Error converting image:", error);
        alert("Failed to process image");
      }
    }
  };
  const loadMoreMessages = () => {
    if (!isLoadingMessages && hasMoreMessages) {
      fetchMessages(page + 1);
    }
  };

  return (
    <SafeAreaView style={tw`flex-1 bg-gray-200`}>
      {/* Header */}
      <ChatHeader
        setSearchModalVisible={setSearchModalVisible}
        RoomInfo={RoomInfo}
        isUserOnline={onlineUsers.includes(user?.id || "")}
      />
      {/* Messages */}
      <FlatList
        ref={flatListRef}
        data={processedMessages}
        keyExtractor={(item, index) => `sticker-${item.id}-${index}`}
        renderItem={renderItem}
        contentContainerStyle={tw`flex-grow`}
        inverted
        onEndReached={loadMoreMessages}
        onEndReachedThreshold={0.5}
        ListFooterComponent={
          isLoadingMessages && hasMoreMessages ? (
            <View style={tw`py-4`}>
              <ActivityIndicator size="small" color="#0000ff" />
            </View>
          ) : null
        }
      />

      {/* Message Input */}
      <MessageInput
        isSendingMessageLoading={isSendingMessageLoading}
        pickImage={pickImage}
        setStickerPickerVisible={setStickerPickerVisible}
        inputText={inputText}
        setInputText={setInputText}
        sendMessage={sendMessage}
      />

      {/* Sticker  */}
      <StickersComp
        sendStickerMessage={sendStickerMessage}
        setStickerPickerVisible={setStickerPickerVisible}
        isStickerPickerVisible={isStickerPickerVisible}
      />

      {/* Search Modal */}
      <SearchMessage
        searchModalVisible={searchModalVisible}
        setSearchModalVisible={setSearchModalVisible}
        messages={messages}
        renderMessageItem={renderMessageItem}
      />
    </SafeAreaView>
  );
};

export default ChatScreen;
const renderMessageItem = ({ item }: { item: Message }) => {
  const isUser = item.fromMe;

  return (
    <View
      style={[
        tw`mb-2 mx-2 max-w-3/4 mt-2 px-2`,
        isUser ? tw`self-end items-end` : tw`self-start items-start`,
      ]}
    >
      <View
        style={[
          tw`px-2 py-2`,
          {
            backgroundColor: isUser ? "#DCF8C6" : "#FFFFFF",
            borderRadius: 10,
            borderTopLeftRadius: isUser ? 10 : 0,
            borderTopRightRadius: isUser ? 0 : 10,
          },
        ]}
      >
        {item.type === "image" && (
          <Image
            source={{
              uri: item.content,
            }}
            resizeMode={"cover"}
            style={{ width: 200, height: 200, borderRadius: 10 }}
            onError={(e) => {
              console.error("Image load error", e.nativeEvent.error);
            }}
          />
        )}

        {item.type === "sticker" && (
          <View style={[tw`flex-row flex-wrap bg-white`]}>
            {item.content.split("-").map((id, index) => {
              const sticker = allStickers.find((s) => s.id === id);
              return sticker ? (
                <Image
                  key={index}
                  source={sticker.path}
                  resizeMode="contain"
                  style={{ width: 50, height: 50, marginHorizontal: 2 }}
                  onError={(e) => {
                    console.error(
                      `Image load error for sticker ${id}`,
                      e.nativeEvent.error
                    );
                  }}
                />
              ) : null;
            })}
          </View>
        )}

        {item.type === "text" && (
          <Text style={isUser ? tw`text-black` : tw`text-black`}>
            {item.content}
          </Text>
        )}
      </View>

      <View style={tw`flex-row items-center mt-1`}>
        <Text style={tw`text-gray-500 text-xs`}>
          {new Date(item.createdAt).toLocaleTimeString([], {
            hour: "2-digit",
            minute: "2-digit",
          })}
        </Text>
        {isUser && (
          <Ionicons
            name="checkmark-done"
            size={14}
            color={item.isRead ? "#34B7F1" : "gray"}
            style={tw`ml-1`}
          />
        )}
      </View>
    </View>
  );
};
const formatMessageDate = (date: Date) => {
  const now = new Date();
  const messageDate = new Date(date);

  // Check if it's today or yesterday
  const yesterday = new Date(now);
  yesterday.setDate(yesterday.getDate() - 1);

  // If message is from today or yesterday, don't show date separator
  if (
    messageDate.toDateString() === now.toDateString() ||
    messageDate.toDateString() === yesterday.toDateString()
  ) {
    return ""; // Return empty string for today and yesterday
  }

  // For older dates, show the date
  return messageDate.toLocaleDateString("en-US", {
    month: "long",
    day: "numeric",
    year: "numeric",
  });
};
const DateSeparator = ({ date }: { date: string }) => (
  <View style={tw`flex-row justify-center items-center my-2`}>
    <View style={tw`bg-gray-300 px-3 py-1 rounded-full`}>
      <Text style={tw`text-xs text-gray-700`}>{date}</Text>
    </View>
  </View>
);
const processMessagesWithDateSeparators = (messages: Message[]) => {
  const processedMessages: (
    | Message
    | { id: string; type: "dateSeparator"; date: string }
  )[] = [];
  let currentDate = "";

  messages.forEach((message) => {
    const messageDate = formatMessageDate(new Date(message.createdAt));

    if (messageDate !== currentDate) {
      processedMessages.push({
        id: `date-${message.createdAt}`,
        type: "dateSeparator",
        date: messageDate,
      });
      currentDate = messageDate;
    }
    processedMessages.push(message);
  });

  return processedMessages;
};
