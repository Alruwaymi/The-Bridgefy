import * as SecureStore from "expo-secure-store";
import { create } from "zustand";

import axiosInstance from "../api/axiosInstance";

const useStore = create((set, get) => ({
  // Initial state
  user: null,
  loading: false,
  error: null,

  // Function to set user
  setUser: (userData) => set({ user: userData }),
  setLogOut: () => set({ user: null, token: null }),
  // Login action
  login: async (email, password) => {
    set({ loading: true, error: null });
    try {
      const response = await axiosInstance.post("/auth/login", {
        email: String(email),
        password: String(password),
      });

      console.log("Login response data:", response.data);

      // Correctly extract token and user from the nested "data" object
      const { data } = response.data;
      const { token, user } = data;

      console.log("Type of token:", typeof token);

      if (!token || typeof token !== "string") {
        throw new Error("Invalid token received from server");
      }

      // Save token to SecureStore
      await SecureStore.setItemAsync("authToken", token);
      const userString = typeof user !== "string" ? JSON.stringify(user) : user;
      await SecureStore.setItemAsync("user", userString);

      set({ user });
    } catch (error) {
      console.error("Login error:", error);
      alert("Wrong  user name or Password .");
      let errorMessage = "An error occurred during login.";
      if (
        error.response &&
        error.response.data &&
        error.response.data.message
      ) {
        errorMessage = error.response.data.message;
      } else if (error.message) {
        errorMessage = error.message;
      }

      set({ error: errorMessage });
    } finally {
      set({ loading: false });
    }
  },

  // Initialize signUpData
  signUpData: {
    profileImage: {},
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    status: "", // 'deaf' or 'hearing'
    translationMethod: "", // 'text' or 'sticker'
  },

  // Action to update sign-up data
  updateSignUpData: (data) =>
    set((state) => ({
      signUpData: { ...state.signUpData, ...data },
    })),

  // Sign-up action
  signUp: async () => {
    set({ loading: true, error: null });
    const { signUpData } = get(); // Use get() to access the current state

    try {
      // Ensure all required fields are present
      const {
        profileImage,
        firstName,
        lastName,
        email,
        password,
        status,
        translationMethod,
      } = signUpData;

      if (
        !firstName ||
        !lastName ||
        !email ||
        !password ||
        !status ||
        !translationMethod
      ) {
        throw new Error("Please complete all sign-up steps.");
      }

      // Prepare the data according to the schema
      const payload = {
        profileImage: profileImage ?? undefined,
        firstName,
        lastName,
        status,
        translationMethod,
        email,
        password,
      };
      // Create FormData instance
      // const formData = new FormData();

      // Make the API call
      console.log("🚀 ~ signUp: ~ response:", JSON.stringify(payload, null, 2));
      const response = await axiosInstance.post("/auth/signup", payload);

      // Assume the response structure is similar to the login response
      const { data } = response.data;
      const { token, user } = data;

      if (!token || typeof token !== "string") {
        throw new Error("Invalid token received from server");
      }

      // Save token to SecureStore
      await SecureStore.setItemAsync("authToken", token);
      const userString = typeof user !== "string" ? JSON.stringify(user) : user;
      await SecureStore.setItemAsync("user", userString);

      set({ user, signUpData: {} });

      return true; // Indicate success
    } catch (error) {
      console.error("Sign-up error:", error);

      let errorMessage = "An error occurred during sign-up.";
      if (
        error.response &&
        error.response.data &&
        error.response.data.message
      ) {
        errorMessage = error.response.data.message;
      } else if (error.message) {
        errorMessage = error.message;
      }

      set({ error: errorMessage });

      // Throw the error to be caught in the component
      throw new Error(errorMessage);
    } finally {
      set({ loading: false });
    }
  },
}));

export default useStore;
