import * as Notifications from "expo-notifications";
import * as SecureStore from "expo-secure-store";
import * as Device from "expo-device";
import React, { useEffect, useState, useRef } from "react";
import { Platform, AppState } from "react-native";
import AppNavigator from "./navigation/AppNavigation";
import AuthNavigator from "./navigation/AuthNavigation";
import useStore from "./store/useStore";
import * as TaskManager from "expo-task-manager";

// Define background task name
const BACKGROUND_NOTIFICATION_TASK = "BACKGROUND-NOTIFICATION-TASK";

// Register background task
TaskManager.defineTask(
  BACKGROUND_NOTIFICATION_TASK,
  async ({ data, error }) => {
    if (error) {
      console.error("Background task error:", error);
      return;
    }

    if (data) {
      const { notification } = data as {
        notification: Notifications.Notification;
      };
      // Store the notification in AsyncStorage for handling when app opens
      try {
        const existingNotifications = await SecureStore.getItemAsync(
          "pendingNotifications"
        );
        const notifications = existingNotifications
          ? JSON.parse(existingNotifications)
          : [];
        notifications.push(notification);
        await SecureStore.setItemAsync(
          "pendingNotifications",
          JSON.stringify(notifications)
        );
      } catch (error) {
        console.error("Error storing notification:", error);
      }
    }
  }
);

// Configure notification handler with high priority
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: true,
    priority: Notifications.AndroidNotificationPriority.MAX,
  }),
});

async function registerForPushNotificationsAsync() {
  let token;

  if (Platform.OS === "android") {
    await Notifications.setNotificationChannelAsync("default", {
      name: "Default Channel",
      importance: Notifications.AndroidImportance.MAX,
      vibrationPattern: [0, 250, 250, 250],
      lightColor: "#FF231F7C",
      enableVibrate: true,
      enableLights: true,
      sound: "default",
      lockscreenVisibility: Notifications.AndroidNotificationVisibility.PUBLIC,
      bypassDnd: true,
    });
  }

  if (Device.isDevice) {
    try {
      const { status: existingStatus } =
        await Notifications.getPermissionsAsync();
      let finalStatus = existingStatus;

      if (existingStatus !== "granted") {
        const { status } = await Notifications.requestPermissionsAsync({
          ios: {
            allowAlert: true,
            allowBadge: true,
            allowSound: true,
          },
          android: {
            allowAlert: true,
            allowBadge: true,
            allowSound: true,
          },
        });
        finalStatus = status;
      }

      if (finalStatus !== "granted") {
        throw new Error("Permission not granted");
      }

      const { data: expoPushToken } = await Notifications.getExpoPushTokenAsync(
        {
          projectId: "56091626-bded-4cfe-ae70-9a50febd1546",
        }
      );
      token = expoPushToken;

      // Register for background notifications
      await Notifications.registerTaskAsync(BACKGROUND_NOTIFICATION_TASK);
    } catch (error) {
      console.error("Error setting up push notifications:", error);
    }
  }

  return token;
}

export default function App() {
  const { user, token } = useStore();
  const [userToken, setUserToken] = useState<string | null>(null);
  const [expoPushToken, setExpoPushToken] = useState<string>("");
  const appState = useRef(AppState.currentState);
  const notificationListener = useRef<any>();
  const responseListener = useRef<any>();

  // Function to handle notifications when app opens
  const handlePendingNotifications = async () => {
    try {
      const pendingNotifications = await SecureStore.getItemAsync(
        "pendingNotifications"
      );
      if (pendingNotifications) {
        const notifications = JSON.parse(pendingNotifications);
        // Handle pending notifications
        notifications.forEach((notification: any) => {
          handleNotification(notification);
        });
        // Clear pending notifications
        await SecureStore.deleteItemAsync("pendingNotifications");
      }
    } catch (error) {
      console.error("Error handling pending notifications:", error);
    }
  };

  // Handle notification
  const handleNotification = (notification: Notifications.Notification) => {
    const { data } = notification.request.content;
    console.log("Handling notification:", data);
    // Add your notification handling logic here
  };

  useEffect(() => {
    let isMounted = true;

    const setupNotifications = async () => {
      try {
        const token = await registerForPushNotificationsAsync();
        if (token && isMounted) {
          setExpoPushToken(token);
          // Send token to your backend here
          console.log("Push token:", token);
        }

        // Handle notifications when app is in foreground
        notificationListener.current =
          Notifications.addNotificationReceivedListener((notification) => {
            if (isMounted) {
              handleNotification(notification);
            }
          });

        // Handle notification response when app is in background
        responseListener.current =
          Notifications.addNotificationResponseReceivedListener((response) => {
            handleNotification(response.notification);
          });

        // Handle app state changes
        const subscription = AppState.addEventListener(
          "change",
          (nextAppState) => {
            if (
              appState.current.match(/inactive|background/) &&
              nextAppState === "active"
            ) {
              handlePendingNotifications();
            }
            appState.current = nextAppState;
          }
        );

        // Check for pending notifications on app start
        handlePendingNotifications();

        return () => {
          subscription.remove();
        };
      } catch (error) {
        console.error("Error in setupNotifications:", error);
      }
    };

    setupNotifications();

    return () => {
      isMounted = false;
      if (notificationListener.current) {
        Notifications.removeNotificationSubscription(
          notificationListener.current
        );
      }
      if (responseListener.current) {
        Notifications.removeNotificationSubscription(responseListener.current);
      }
    };
  }, []);

  // Get authentication token
  useEffect(() => {
    const getToken = async () => {
      try {
        const token = await SecureStore.getItemAsync("authToken");
        setUserToken(token);
      } catch (error) {
        console.error("Error retrieving token:", error);
        setUserToken(null);
      }
    };

    getToken();
  }, [user, token]);

  return userToken ? <AppNavigator /> : <AuthNavigator />;
}
