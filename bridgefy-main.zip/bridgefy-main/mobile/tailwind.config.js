/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./App.{js,jsx,ts,tsx}", "./screens/*.{js,jsx,ts,tsx}"], // Add paths to all files using Tailwind
  theme: {
    extend: {
      colors: {
        gray1:"#CDCDCD",
        gray2:"#767676",
        textColor:"#1E1E1E",
        borderColor:"#CAC4D0",
        primary: "#1D4ED8",
        pink1: "#FEF7FF",
        pink2: "#E8DEF8",
      },
    },
  },
  plugins: [],
};
