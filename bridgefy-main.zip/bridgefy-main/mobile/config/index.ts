// src/config/index.ts

export const BASE_URL = "https://api-chat-elbahnsawy.koyeb.app/v1";
export const UNSPLASH_ACCESS_KEY =
  "aXUsM4Fs8xWsdgg_3xgo959N9GphdbefI4hk7Q_mkhQ";
