// import { adminConversation } from "@/components/chat/adminConversation";
// import { playNotification } from "@/services/playNotification";
// import useUserStore from "@/store/useUserStore";
// import {
//   requestNotificationPermission,
//   showBrowserNotification,
//   updateTabTitle,
// } from "@/services/notificationService";

import {
  createContext,
  useState,
  useEffect,
  useContext,
  ReactNode,
  useRef,
} from "react";
import * as SecureStore from "expo-secure-store";
import io, { Socket } from "socket.io-client";
import { BASE_URL } from "../config";
import * as Notifications from "expo-notifications";
interface ISocketContext {
  socket: Socket | null;
  socketError: any;
  setSocketError: any;

  onlineUsers: string[];

  selectedConversation: any | null;
  setSelectedConversation: React.Dispatch<React.SetStateAction<any | null>>;
  hasNotification: boolean;
  setHasNotification: React.Dispatch<React.SetStateAction<boolean>>;
  notificationContent: string;
  setNotificationContent: React.Dispatch<React.SetStateAction<string>>;
}

const ChatContext = createContext<ISocketContext | undefined>(undefined);

export const useChatContext = (): ISocketContext => {
  const context = useContext(ChatContext);
  if (context === undefined) {
    throw new Error(
      "useSocketContext must be used within a SocketContextProvider"
    );
  }
  return context;
};

// const socketURL = process.env.NEXT_PUBLIC_BASE_URL;

const ChatContextProvider = ({ children }: { children: any }) => {
  const socketRef = useRef<Socket | null>(null);
  const [isOpen, setIsOpen] = useState<boolean>(false);
  const [hasNotification, setHasNotification] = useState<boolean>(false);
  const [notificationContent, setNotificationContent] = useState<string>("");
  const [onlineUsers, setOnlineUsers] = useState<string[]>([]);
  const [socketError, setSocketError] = useState<string[]>([]);
  // const [chatLoading, setChatLoading] = useState(false);
  const [selectedConversation, setSelectedConversation] = useState<any | null>(
    null
  );
  const schedulePushNotification = async (message: string) => {
    try {
      const notificationId = await Notifications.scheduleNotificationAsync({
        content: {
          title: "New Message 📬",
          body: message,
          data: { type: "chat", message },
          sound: true,
          priority: Notifications.AndroidNotificationPriority.MAX,
        },
        trigger: {
          seconds: 0.1,
          channelId: "high-priority",
        },
      });
      console.log("Chat notification scheduled:", notificationId);
    } catch (error) {
      console.error("Error scheduling chat notification:", error);
    }
  };
  useEffect(() => {
    const setupSocket = async () => {
      const token = await SecureStore.getItemAsync("authToken");

      if (token) {
        const socket = io(BASE_URL, {
          auth: { token },
        });
        socketRef.current = socket;

        socket.on("online-users", (users: string[]) => {
          setOnlineUsers(users);
        });

        socket.on("error", (error: any) => {
          setSocketError(error);
        });

        socket.on("notification", async ({ content }) => {
          const newContent = areNumbersInRange(content) ? "Sticker" : content;
          console.log("contsent", content);
          await schedulePushNotification(newContent);
          if (!isOpen) {
            setHasNotification(true);
            setNotificationContent(content);
            setTimeout(() => {
              setNotificationContent("");
            }, 3000);
          }
        });

        return () => {
          socket.close();
          socketRef.current = null;
        };
      }
    };

    setupSocket();
  }, [isOpen]);
  // const tokenFunc=async()=>{

  const token = SecureStore.getItem("authToken");
  console.log("token", token);

  //   return token as string;
  // }
  // const user = useUserStore((state) => state.user);
  // const token=tokenFunc()
  // useEffect(() => {
  //   if (token) {
  //     const socket = io(BASE_URL, {
  //       auth: {
  //         token,
  //       },
  //     });
  //     socketRef.current = socket;

  //     // Request notification permission when component mounts
  //     // requestNotificationPermission();

  //     socket.on("online-users", (users: string[]) => {
  //       setOnlineUsers(users);
  //     });
  //     socket.on("error", (error: any) => {
  //       setSocketError(error);
  //     });
  //     socket.on("notification", ({ content }) => {
  //       schedulePushNotification(content);
  //       if (!isOpen) {
  //         // playNotification();
  //         setHasNotification(true);
  //         setNotificationContent(content);
  //         // Show browser notification
  //         // showBrowserNotification("New Message", content);
  //         // Update tab title
  //         // updateTabTitle(true);
  //         setTimeout(() => {
  //           setNotificationContent("");
  //         }, 3000);
  //       }
  //     });
  //     return () => {
  //       socket.close();
  //       socketRef.current = null;
  //     };
  //   } else if (!token) {
  //     if (socketRef.current) {
  //       socketRef.current.close();
  //       socketRef.current = null;
  //     }
  //   }
  // }, [token]);

  // Reset tab title when chat is opened
  // useEffect(() => {
  //   if (isOpen) {
  //     updateTabTitle(false);
  //   }
  // }, [isOpen]);

  return (
    <ChatContext.Provider
      value={{
        socket: socketRef.current,
        onlineUsers,
        socketError,
        setSocketError,

        selectedConversation,
        setSelectedConversation,
        hasNotification,
        setHasNotification,
        notificationContent,
        setNotificationContent,
      }}
    >
      {children}
    </ChatContext.Provider>
  );
};

export default ChatContextProvider;
function areNumbersInRange(str: string) {
  const numbers = str.split("-");

  return numbers.every((num) => {
    const n = Number(num);
    return !isNaN(n) && n >= 1 && n <= 60;
  });
}
