import React, { useEffect } from "react";

import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";

import ChatContextProvider from "../context/socketContext";
import ChatScreen from "../screens/ChatScreen";
import HomeScreen from "../screens/HomeScreen";
import ProfileUpdateScreen from "../screens/ProfileUpdateScreen ";
import ProflieSettingScreen from "../screens/ProflieSettingScreen";
import AboutScreen from "../screens/AboutScreen";

type RootStackParamList = {
  Welcome: undefined;
  SignUpFirstStep: undefined;
  Login: undefined;
  SignUp: undefined;
  ResetPassword: undefined;
  Chat: undefined;
  Home: undefined;
  ProflieSetting: undefined;
  SignUpSecondStep: undefined;
  ForgetPassword: undefined;
  SignUpThirdStep: undefined;
  StickerStoreScreen: undefined;
  StickerStore: undefined;
  About: undefined;
  ProfileUpdate: undefined;
};

const Stack = createStackNavigator<RootStackParamList>();

const AppNavigator = () => {
  return (
    <ChatContextProvider>
      <NavigationContainer>
        <Stack.Navigator
          initialRouteName={"Home"}
          screenOptions={{
            headerShown: false,
            cardStyle: { backgroundColor: "white" },
          }}
        >
          <Stack.Screen name="Home" component={HomeScreen} />
          <Stack.Screen name="About" component={AboutScreen} />
          <Stack.Screen name="Chat" component={ChatScreen} />
          <Stack.Screen name="ProfileUpdate" component={ProfileUpdateScreen} />
          <Stack.Screen
            name="ProflieSetting"
            component={ProflieSettingScreen}
          />
        </Stack.Navigator>
      </NavigationContainer>
    </ChatContextProvider>
  );
};

export default AppNavigator;
