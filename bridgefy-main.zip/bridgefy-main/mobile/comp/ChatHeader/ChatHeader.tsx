import React, { useEffect, useState } from "react";
import { Image, Text, TouchableOpacity, View } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { Ionicons } from "@expo/vector-icons";
import tw from "../../tailwind";
import moment from "moment";
import { useChatContext } from "../../context/socketContext";

interface RoomInfo {
  id: string;
  image: string;
  name: string;
  receiverId: string;
  lastSeen: Date;
}

interface ChatHeaderProps {
  setSearchModalVisible: (visible: boolean) => void;
  RoomInfo: RoomInfo;
  isUserOnline: boolean;
}

const ChatHeader: React.FC<ChatHeaderProps> = ({
  setSearchModalVisible,
  RoomInfo,
  isUserOnline,
}) => {
  const [renderedRoomInfo, setRenderedRoomInfo] = useState<RoomInfo>(RoomInfo);

  const { socket } = useChatContext();
  useEffect(() => {
    RoomInfo && setRenderedRoomInfo(RoomInfo);
  }, [RoomInfo]);
  useEffect(() => {
    if (!socket) return;

    socket.on("update-user-last-seen", (userId: any) => {
      RoomInfo.receiverId === userId &&
        setRenderedRoomInfo((prev) => ({ ...prev, lastSeen: new Date() }));
    });
  }, [socket]);
  console.log("🚀 ~ onlineUsers:", isUserOnline);
  const navigation = useNavigation<any>();
  const lastSeenDate = moment(renderedRoomInfo.lastSeen);
  const now = moment();

  const isToday = lastSeenDate.isSame(now, "day"); // Check if the dates are the same day

  const formattedDate = isToday
    ? "Today, " + lastSeenDate.format("hh:mm A") // Format time if today
    : lastSeenDate.format("dddd, hh:mm A");
  return (
    <>
      {/* <View style={tw`h-7 bg-white`} /> */}
      <View
        style={tw`flex-row items-center px-5 py-1 bg-white border-b border-gray-300`}
      >
        <TouchableOpacity
          onPress={() =>
            navigation.navigate("Home", {
              params: { refresh: Date.now() },
              merge: true,
            })
          }
        >
          <Ionicons name="arrow-back" size={24} color="black" />
        </TouchableOpacity>
        {/* User Image */}
        <Image
          source={{ uri: renderedRoomInfo.image }}
          style={tw`w-10 h-10 rounded-full ml-4`}
        />
        <View style={tw`ml-4 flex-1`}>
          <Text style={tw`text-black text-lg font-bold`}>
            {renderedRoomInfo.name}
          </Text>
          {isUserOnline ? (
            <Text style={tw`  text-green-500  text-sm`}>Online</Text>
          ) : (
            <Text
              style={tw` 
                 
               text-gray1 text-sm`}
            >
              {formattedDate}
            </Text>
          )}
        </View>
        {/* Search Icon */}
        <TouchableOpacity onPress={() => setSearchModalVisible(true)}>
          <Ionicons name="search-outline" size={24} color="black" />
        </TouchableOpacity>
      </View>
    </>
  );
};

export default ChatHeader;
