// Common header component (create a new file: app/components/CustomHeader.tsx)
import React from "react";
import { TouchableOpacity, Text, View } from "react-native";
import { useNavigation } from "@react-navigation/native";
import AntDesign from "@expo/vector-icons/AntDesign";
import tw from "twrnc";

const CustomHeader = () => {
  const navigation = useNavigation();

  return (
    <View style={tw` pt-14 py-16`}>
      <TouchableOpacity
        onPress={() => navigation.goBack()}
        style={tw`flex-row items-center`}
      >
        <Text style={tw`text-black text-md flex items-center gap-4 ml-4`}>
          <AntDesign name="arrowleft" size={14} color="black" /> Previous
        </Text>
      </TouchableOpacity>
    </View>
  );
};

export default CustomHeader;
