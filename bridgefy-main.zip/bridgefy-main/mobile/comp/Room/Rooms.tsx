import React, { useCallback, useEffect, useRef, useState } from "react";

import {
  ActivityIndicator,
  FlatList,
  Text,
  TouchableOpacity,
  View,
} from "react-native";

import { AntDesign, Feather, Ionicons } from "@expo/vector-icons";
import { useFocusEffect } from "@react-navigation/native";
import { TextInput } from "react-native-gesture-handler";

import axiosInstance from "../../api/axiosInstance";
import { useChatContext } from "../../context/socketContext";
import useDebounce from "../../hooks/debounce";
import tw from "../../tailwind";
import ChatItem from "./_comp/ChatItem";
import UserItem from "./_comp/userItem";
import { uniqueAdvanced } from "../../utils/arr";

interface ChatRoom {
  id: string;
  name: string;
  image: string;
  lastSeen: Date;
  receiverId: string;
  lastMessage: {
    id: string;
    content: string;
    createdAt: string;
    type: string;
  };
  unreadMessagesCount: number;
}

const Rooms = ({ navigation }: { navigation: any }) => {
  const [isSearchMsgOPened, setIsSearchMsgOpened] = useState(false);
  const [isSearchContactOpened, setIsSearchContactOpened] = useState(false);
  const [search, setSearch] = useState("");
  const [searchByUser, setSearchByUser] = useState("");
  const [chatData, setChatData] = useState<ChatRoom[]>([]);
  const [page, setPage] = useState(1);
  const [pageSize] = useState(20);
  const [loading, setLoading] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const { socket } = useChatContext();

  const debouncedFetch = useDebounce(
    useCallback(
      (
        searchTerm: string,
        resetData: boolean = false,
        isContactSearch: boolean
      ) => {
        if (isContactSearch) {
          fetchChatUsers(searchTerm, resetData);
        } else {
          fetchChatRooms(searchTerm, resetData);
        }
      },
      [search, searchByUser]
    ),
    300
  );

  const fetchChatRooms = async (searchTerm = search, resetData = false) => {
    if (loading || (!hasMore && !resetData)) return;

    setLoading(true);
    try {
      const response = await axiosInstance.get("/rooms", {
        params: {
          page: resetData ? 1 : page,
          pageSize,
          search: searchTerm,
        },
      });

      const { list, pagination } = response.data.data;

      setChatData((prevChats) => (resetData ? list : [...prevChats, ...list]));

      setPage(resetData ? 2 : page + 1);
      setHasMore(pagination.hasMore);
    } catch (error) {
      console.error("Error fetching rooms:", error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };
  const fetchChatUsers = async (
    searchTerm = searchByUser,
    resetData = false
  ) => {
    if (loading || (!hasMore && !resetData)) return;

    setLoading(true);
    try {
      const response = await axiosInstance.get("/users", {
        params: {
          page: resetData ? 1 : page,
          pageSize,
          search: searchTerm,
        },
      });

      const { list, pagination } = response.data.data;
      console.log("🚀 ~bbbbbbbbbb", list);

      setChatData((prevChats) => (resetData ? list : [...prevChats, ...list]));

      setPage(resetData ? 2 : page + 1);
      setHasMore(pagination.hasMore);
    } catch (error) {
      console.error("Error fetching rooms:", error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const isFirstMount = useRef(true);

  useEffect(() => {
    if (isFirstMount.current) {
      isFirstMount.current = false;
      fetchChatRooms("", true);
      return;
    }

    setPage(1);
    setHasMore(true);

    debouncedFetch(
      isSearchContactOpened ? searchByUser : search,
      true,
      isSearchContactOpened
    );
  }, [search, searchByUser, isSearchContactOpened]);

  // useEffect(() => {
  //   const unsubscribe = navigation.addListener("focus", () => {
  //     // This will run when screen focuses
  //     fetchChatRooms("", true);
  //   });

  //   return unsubscribe;
  // }, [navigation]);

  useFocusEffect(
    React.useCallback(() => {
      // This will run every time the screen comes into focus
      fetchChatRooms("", true);
    }, [])
  );
  useEffect(() => {
    if (!socket) return;

    socket.on("update-conversation-last-seen", (userId: any) => {
      const newChatData = chatData.map((item) =>
        item.receiverId === userId ? { ...item, lastSeen: new Date() } : item
      );
      setChatData(newChatData);
      // RoomInfo.receiverId === userId &&
      // setRenderedRoomInfo((prev) => ({ ...prev, lastSeen: new Date() }));
    });
  }, [socket]);
  useEffect(() => {
    const handleNewMessage = (room: ChatRoom) => {
      console.log("jdroomhd", room);
      console.log("jdroomhsd", chatData);
      fetchChatRooms("", true);
      // setChatData((prevRooms) => {
      //   const existingRoomIndex = prevRooms.findIndex((r) => r.id === room.id);

      //   if (existingRoomIndex !== -1) {
      //     const updatedRooms = [...prevRooms];
      //     updatedRooms[existingRoomIndex] = room;
      //     return updatedRooms;
      //   }

      //   return [room, ...prevRooms];
      // });
    };

    socket?.on("new-room-message", handleNewMessage);

    return () => {
      socket?.off("new-room-message", handleNewMessage);
    };
  }, [socket]);

  const handleRefresh = useCallback(() => {
    setRefreshing(true);
    setPage(1);
    setHasMore(true);
    fetchChatRooms(search, true);
  }, []);
  useEffect(() => {
    fetchChatRooms("", true);
  }, []);
  const renderItem = ({ item }: { item: ChatRoom | any }) =>
    isSearchContactOpened ? (
      <UserItem
        user={item}
        onPress={async () => {
          try {
            const response = await axiosInstance.post("/rooms", {
              receiverId: item.id,
            });

            console.log("🚀 ~ onPress={ ~ response:", response.data.data);
            navigation.navigate("Chat", { RoomInfo: response.data.data });
            setIsSearchMsgOpened(false);
            setIsSearchContactOpened(false);
          } catch (error) {
            console.error("Error fetching rooms:", error);
            setIsSearchMsgOpened(false);
            setIsSearchContactOpened(false);
          }
        }}
      />
    ) : (
      <ChatItem
        user={item}
        onPress={() => navigation.navigate("Chat", { RoomInfo: item })}
      />
    );

  const handleSearchClose = () => {
    setIsSearchMsgOpened(false);
    setIsSearchContactOpened(false);
    setSearch("");
    setSearchByUser("");
  };

  return (
    <View style={tw`flex-1`}>
      <View style={tw`bg-white h-8`} />

      {isSearchMsgOPened || isSearchContactOpened ? (
        <>
          {isSearchContactOpened ? (
            <View style={tw`px-4 mt-4 w-full bg-gray-100`}>
              <View
                style={tw`flex-row items-center border border-gray-300 rounded-full h-12 px-4 bg-white`}
              >
                <TouchableOpacity onPress={handleSearchClose}>
                  <AntDesign
                    name="arrowleft"
                    size={24}
                    color="black"
                    style={tw`mr-2`}
                  />
                </TouchableOpacity>
                <TextInput
                  placeholder="Search New User ..."
                  value={searchByUser}
                  onChangeText={setSearchByUser}
                  style={tw`flex-1`}
                />
                {search.length > 0 && (
                  <TouchableOpacity onPress={() => setSearchByUser("")}>
                    <Ionicons name="close-circle" size={24} color="gray" />
                  </TouchableOpacity>
                )}
              </View>
            </View>
          ) : (
            <View style={tw`px-4 mt-4 w-full bg-gray-100`}>
              <View
                style={tw`flex-row items-center border border-gray-300 rounded-full h-12 px-4 bg-white`}
              >
                <TouchableOpacity onPress={handleSearchClose}>
                  <AntDesign
                    name="arrowleft"
                    size={24}
                    color="black"
                    style={tw`mr-2`}
                  />
                </TouchableOpacity>
                <TextInput
                  placeholder="Search ..."
                  value={search}
                  onChangeText={setSearch}
                  style={tw`flex-1`}
                />
                {search.length > 0 && (
                  <TouchableOpacity onPress={() => setSearch("")}>
                    <Ionicons name="close-circle" size={24} color="gray" />
                  </TouchableOpacity>
                )}
              </View>
            </View>
          )}
        </>
      ) : (
        <View
          style={tw`pt-5 w-full px-4 flex-row justify-between items-center mx-auto bg-gray-100`}
        >
          <Text style={tw`text-black text-4xl font-extrabold`}>Bridgefy</Text>
          <View style={tw`flex-row gap-4 items-center`}>
            <TouchableOpacity
              onPress={() => setIsSearchContactOpened(true)}
              style={tw`border border-black rounded-lg rounded-bl-none`}
            >
              <Feather name="plus" size={24} color="black" />
            </TouchableOpacity>
            <TouchableOpacity onPress={() => setIsSearchMsgOpened(true)}>
              <Ionicons
                name="search-outline"
                style={tw`rounded-full p-2`}
                size={30}
                color="black"
              />
            </TouchableOpacity>
          </View>
        </View>
      )}

      {/* Chat List */}
      <FlatList
        style={tw`bg-white mt-4 shadow`}
        data={uniqueAdvanced(chatData, { key: "id" })}
        keyExtractor={(item, index) => `rooms-${item.id}-${index}`}
        renderItem={renderItem}
        onEndReached={() => !loading && hasMore && fetchChatRooms()}
        onEndReachedThreshold={0.5}
        refreshing={refreshing}
        onRefresh={handleRefresh}
        ListEmptyComponent={() => (
          <View style={tw`flex-1 justify-center items-center py-8`}>
            <Text style={tw`text-gray-500`}>
              {loading ? "Loading..." : "No chats found"}
            </Text>
          </View>
        )}
        ListFooterComponent={() =>
          loading && hasMore ? (
            <View style={tw`py-4`}>
              <ActivityIndicator size="small" color="#000" />
            </View>
          ) : null
        }
      />
    </View>
  );
};

export default Rooms;
