import React from "react";
import { View, Text, TouchableOpacity, Image } from "react-native";
import {
  Ionicons,
  Feather,
  FontAwesome5,
  FontAwesome6,
} from "@expo/vector-icons";
import tw from "../tailwind";

const CustomFooter = ({
  handleNavigateToRooms,
  handleNavigateToSettings,
  currentRoute,
}: {
  handleNavigateToSettings: any;
  handleNavigateToRooms: any;
  currentRoute: string;
}) => {
  return (
    <View
      style={tw`flex-row items-center justify-evenly mt-auto py-8 bg-white shadow-xl`}
    >
      <TouchableOpacity
        onPress={handleNavigateToSettings}
        style={tw`${
          currentRoute === "settings" ? "bg-purple-900" : "bg-pink2"
        } p-3 rounded-full`}
      >
        <Ionicons
          name="settings-outline"
          size={24}
          color={currentRoute === "settings" ? "white" : "black"}
        />
      </TouchableOpacity>
      <TouchableOpacity
        onPress={handleNavigateToRooms}
        style={tw`${
          currentRoute === "rooms" ? "bg-purple-900" : "bg-pink2"
        } p-3 rounded-full`}
      >
        <Ionicons
          name="chatbubbles-outline"
          size={24}
          color={currentRoute === "rooms" ? "white" : "black"}
        />
      </TouchableOpacity>
    </View>
  );
};

export default CustomFooter;
