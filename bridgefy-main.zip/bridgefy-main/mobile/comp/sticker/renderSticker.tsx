// import React from "react";
// import { View, Image, Dimensions } from "react-native";

// // Define types for sticker and allStickers
// interface Sticker {
//   id: number;
//   path: any;
//   en: string;
//   ar: string;
// }

// // Declare allStickers as a global variable or import it
// declare const allStickers: Sticker[];

// const { width: SCREEN_WIDTH } = Dimensions.get("window");

// interface RenderStickerMessageProps {
//   item: string | { content: string } | any;
// }

// const renderStickerMessage: React.FC<RenderStickerMessageProps> = ({
//   item,
// }) => {
//   try {
//     // Ensure item is an object and content is a string
//     const content =
//       typeof item === "object" && item.content ? item.content : item;

//     // Ensure content is a string and can be split
//     const stickerIds: string[] =
//       typeof content === "string"
//         ? content.split("-").filter((id) => id.trim() !== "")
//         : [];

//     const calculateResponsiveLayout = (ids: string[]) => {
//       const rows: Sticker[][] = [[]];
//       let currentRow = rows[0];
//       let currentLineWidth = 0;

//       const STICKER_SIZE = SCREEN_WIDTH * 0.12;
//       const MARGIN = 4;

//       ids.forEach((id) => {
//         const sticker = allStickers.find((s) => s.id === parseInt(id, 10));

//         if (sticker) {
//           const stickerTotalWidth = STICKER_SIZE + MARGIN * 2;

//           if (currentLineWidth + stickerTotalWidth > SCREEN_WIDTH * 0.9) {
//             currentRow = [];
//             rows.push(currentRow);
//             currentLineWidth = 0;
//           }

//           currentRow.push(sticker);
//           currentLineWidth += stickerTotalWidth;
//         }
//       });

//       return rows;
//     };

//     const stickerRows = calculateResponsiveLayout(stickerIds);

//     // If no stickers found, return null
//     if (stickerRows.length === 0 || stickerRows[0].length === 0) {
//       return null;
//     }

//     return (
//       <View style={{ flexDirection: "column", backgroundColor: "white" }}>
//         {stickerRows.map((row, rowIndex) => (
//           <View
//             key={rowIndex}
//             style={{
//               flexDirection: "row",
//               alignItems: "center",
//               marginVertical: 2,
//               flexWrap: "wrap",
//             }}
//           >
//             {row.map((sticker, index) => (
//               <Image
//                 key={index}
//                 source={sticker.path}
//                 resizeMode="contain"
//                 style={{
//                   width: SCREEN_WIDTH * 0.12,
//                   height: SCREEN_WIDTH * 0.12,
//                   margin: 4,
//                 }}
//                 onError={(e) => {
//                   console.error(
//                     `Image load error for sticker ${sticker.id}`,
//                     e.nativeEvent.error
//                   );
//                 }}
//               />
//             ))}
//           </View>
//         ))}
//       </View>
//     );
//   } catch (error) {
//     console.error("Error rendering sticker message", error);
//     return null;
//   }
// };

// export default renderStickerMessage;
