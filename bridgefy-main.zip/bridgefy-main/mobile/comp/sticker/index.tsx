import React, { useEffect, useState } from "react";
import {
  ActivityIndicator,
  Dimensions,
  FlatList,
  Image,
  Modal,
  SafeAreaView,
  Text,
  TextInput,
  TouchableOpacity,
  View,
  ScrollView,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import tw from "../../tailwind";

import {
  stickers,
  stickerIcons,
  punctuationMarks,
  allStickers,
} from "../../const/sticker";

interface Sticker {
  id: number;
  path: any;
  en: string;
  ar: string;
  type: "word" | "punctuation" | "icon";
}

interface StickersCompProps {
  sendStickerMessage: (stickers: string) => void;
  setStickerPickerVisible: (visible: boolean) => void;
  isStickerPickerVisible: boolean;
}

type FilterType = "all" | "words" | "icons" | "punctuation";
type LanguageType = "en" | "ar";

const { width } = Dimensions.get("window");
const STICKER_SIZE = width / 4 - 20;

export const StickersComp: React.FC<StickersCompProps> = ({
  sendStickerMessage,
  setStickerPickerVisible,
  isStickerPickerVisible,
}) => {
  const [activeStickers, setActiveStickers] = useState<Sticker[]>([]);
  const [selectedStickers, setSelectedStickers] = useState<Sticker[][]>([[]]);
  const [currentLineIndex, setCurrentLineIndex] = useState(0);
  const [searchText, setSearchText] = useState("");
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [activeFilter, setActiveFilter] = useState<FilterType>("words");
  const [language, setLanguage] = useState<LanguageType>("en");

  const filters = [
    // {
    //   id: "all",
    //   label: { en: "All", ar: "الكل" },
    //   data: allStickers,
    // },
    {
      id: "words",
      label: { en: "Arabic", ar: "عربي" },
      data: stickers,
    },
    {
      id: "icons",
      label: { en: "ASL", ar: "انجليزي" },
      data: stickerIcons,
    },
    {
      id: "punctuation",
      label: { en: "Punctuation", ar: "علامات الترقيم" },
      data: punctuationMarks,
    },
  ];

  useEffect(() => {
    if (isStickerPickerVisible) {
      handleFilterChange("words");
    }
  }, [isStickerPickerVisible]);

  const handleFilterChange = (filterType: FilterType) => {
    setActiveFilter(filterType);
    const filteredData = filters.find((f) => f.id === filterType)?.data || [];

    if (searchText) {
      handleSearch(searchText, filteredData);
    } else {
      setActiveStickers(filteredData);
    }
  };

  const handleSearch = (
    text: string,
    currentData = filters.find((f) => f.id === activeFilter)?.data || []
  ) => {
    setSearchText(text);
    setIsLoading(true);

    const filteredStickers = currentData.filter(
      (sticker) =>
        sticker.en.toLowerCase().includes(text.toLowerCase()) ||
        sticker.ar.includes(text)
    );

    setActiveStickers(filteredStickers);
    setIsLoading(false);
  };

  const toggleLanguage = () => {
    setLanguage((prev) => (prev === "en" ? "ar" : "en"));
  };

  const handleStickerSelect = (sticker: Sticker) => {
    const updatedLines = [...selectedStickers];

    // Prevent adding multiple punctuation marks consecutively
    if (
      sticker.type === "punctuation" &&
      updatedLines[currentLineIndex].length > 0 &&
      updatedLines[currentLineIndex][updatedLines[currentLineIndex].length - 1]
        .type === "punctuation"
    ) {
      return;
    }

    // Add sticker to current line
    updatedLines[currentLineIndex].push(sticker);
    setSelectedStickers(updatedLines);
  };

  const addNewLine = () => {
    setSelectedStickers([...selectedStickers, []]);
    setCurrentLineIndex(currentLineIndex + 1);
  };

  const removeLastSticker = () => {
    const updatedLines = [...selectedStickers];
    if (updatedLines[currentLineIndex].length > 0) {
      updatedLines[currentLineIndex].pop();
      setSelectedStickers(updatedLines);
    } else if (updatedLines.length > 1) {
      // Remove empty line and move to previous line
      updatedLines.pop();
      setSelectedStickers(updatedLines);
      setCurrentLineIndex(currentLineIndex - 1);
    }
  };

  const clearAllStickers = () => {
    setSelectedStickers([[]]);
    setCurrentLineIndex(0);
  };

  const sendConstructedMessage = () => {
    // Flatten the 2D array and get all sticker IDs
    const allStickers = selectedStickers.flat();
    if (allStickers.length > 0) {
      const stickerIdString = allStickers
        .map((sticker) => sticker.id)
        .join("-");
      sendStickerMessage(stickerIdString);
      setSelectedStickers([[]]);
      setCurrentLineIndex(0);
      setStickerPickerVisible(false);
    }
  };

  const renderSelectedStickersPreview = () => (
    <View style={tw`bg-gray-100 p-2 max-h-74`}>
      <ScrollView>
        {selectedStickers.map((line, lineIndex) => (
          <TouchableOpacity
            key={lineIndex}
            onPress={() => setCurrentLineIndex(lineIndex)}
            style={tw`flex-row items-center mb-2 ${
              lineIndex === currentLineIndex ? "bg-blue-100" : ""
            } p-1 rounded`}
          >
            <ScrollView horizontal>
              {line.map((sticker, index) => (
                <Image
                  key={index}
                  source={sticker.path}
                  style={{ width: 50, height: 50, marginHorizontal: 2 }}
                  resizeMode="contain"
                />
              ))}
            </ScrollView>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* Action Buttons */}
      <View style={tw`flex-row justify-between mt-2`}>
        <View style={tw`flex-row`}>
          <TouchableOpacity
            onPress={removeLastSticker}
            style={tw`mr-2 bg-gray-200 p-2 rounded-full`}
          >
            <Ionicons name="backspace" size={20} color="black" />
          </TouchableOpacity>
          <TouchableOpacity
            onPress={addNewLine}
            style={tw`mr-2 bg-green-100 p-2 rounded-full`}
          >
            <Ionicons name="add" size={20} color="green" />
          </TouchableOpacity>
        </View>

        <View style={tw`flex-row`}>
          <TouchableOpacity
            onPress={clearAllStickers}
            style={tw`mr-2 bg-red-100 p-2 rounded-full`}
          >
            <Ionicons name="trash" size={20} color="red" />
          </TouchableOpacity>
          <TouchableOpacity
            onPress={sendConstructedMessage}
            style={tw`bg-blue-100 p-2 rounded-full`}
          >
            <Ionicons name="send" size={20} color="blue" />
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );

  const renderStickerItem = ({ item }: { item: Sticker }) => (
    <TouchableOpacity
      onPress={() => handleStickerSelect(item)}
      style={tw`w-1/4 items-center justify-center p-2`}
    >
      <Image
        source={item.path}
        style={{
          width: STICKER_SIZE,
          height: STICKER_SIZE,
          maxWidth: 100,
          maxHeight: 100,
        }}
        resizeMode="contain"
      />
    </TouchableOpacity>
  );

  return (
    <Modal
      visible={isStickerPickerVisible}
      animationType="slide"
      onRequestClose={() => setStickerPickerVisible(false)}
    >
      <SafeAreaView style={tw`flex-1 bg-white`}>
        {/* Header */}
        <View style={tw`px-4 py-2 bg-white shadow-sm`}>
          <View style={tw`flex-row items-center`}>
            <TouchableOpacity onPress={() => setStickerPickerVisible(false)}>
              <Ionicons name="close" size={24} color="black" />
            </TouchableOpacity>

            {/* Language Toggle */}
            {/* <TouchableOpacity
              onPress={toggleLanguage}
              style={tw`mx-2 px-3 py-1 bg-gray-200 rounded-full`}
            >
              <Text>{language.toUpperCase()}</Text>
            </TouchableOpacity> */}

            {/* Search Input */}
            <TextInput
              style={tw`flex-1 bg-gray-100 rounded-full px-4 py-2 mx-4`}
              placeholder={
                language === "en" ? "Search stickers" : "البحث عن الملصقات"
              }
              value={searchText}
              onChangeText={(text) => handleSearch(text)}
            />
            {searchText !== "" && (
              <TouchableOpacity
                onPress={() => {
                  setSearchText("");
                  handleFilterChange(activeFilter);
                }}
              >
                <Ionicons name="close-circle" size={24} color="gray" />
              </TouchableOpacity>
            )}
          </View>

          {/* Filter Tabs */}
          <View style={tw`flex-row justify-between mt-4`}>
            {filters.map((filter) => (
              <TouchableOpacity
                key={filter.id}
                onPress={() => handleFilterChange(filter.id as FilterType)}
                style={tw`flex-1 items-center py-2 mx-1 rounded-full ${
                  activeFilter === filter.id ? "bg-blue-500" : "bg-gray-200"
                }`}
              >
                <Text
                  style={tw`text-xs py-1 ${
                    activeFilter === filter.id ? "text-white" : "text-black"
                  }`}
                >
                  {filter.label[language]}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Selected Stickers Preview */}
        {renderSelectedStickersPreview()}

        {/* Stickers Grid */}
        {isLoading ? (
          <View style={tw`flex-1 justify-center items-center`}>
            <ActivityIndicator size="large" color="#0000ff" />
            <Text>{language === "en" ? "Loading..." : "جاري التحميل..."}</Text>
          </View>
        ) : (
          <FlatList
            data={activeStickers}
            keyExtractor={(item) => item.id.toString()}
            renderItem={renderStickerItem}
            numColumns={4}
            contentContainerStyle={tw`pb-20`}
            ListEmptyComponent={() => (
              <View style={tw`flex-1 justify-center items-center p-4`}>
                <Text>
                  {language === "en"
                    ? "No stickers found"
                    : "لم يتم العثور على ملصقات"}
                </Text>
              </View>
            )}
          />
        )}
      </SafeAreaView>
    </Modal>
  );
};
