import { Image, Text, View } from "react-native";
import { allStickers } from "../../const/sticker";
import tw from "../../tailwind";

interface Sticker {
  id: string;
  path: any;
  en: string;
  ar: string;
}

interface SentenceConstructionOptions {
  language?: "en" | "ar";
  separator?: string;
}

function constructSentenceFromStickers(
  stickerIds: string,
  options: SentenceConstructionOptions = {}
): string {
  const { language = "en", separator = " " } = options;

  // Split the sticker IDs
  const ids = stickerIds.split("-");

  // Map sticker IDs to their corresponding stickers
  const stickers = ids
    .map((id) => {
      const sticker = allStickers.find((sticker) => sticker.id === id);

      // Additional logic for letter classification
      if (sticker) {
        const numId = parseInt(id);
        if (numId >= 1 && numId <= 28) {
          // Arabic letters (1-28)
          return {
            ...sticker,
            type: "Arabic Letter",
          };
        } else if (numId >= 29 && numId <= 55) {
          // English letters (29-55)
          return {
            ...sticker,
            type: "English Letter",
          };
        }
      }

      return sticker;
    })
    .filter(Boolean) as Sticker[];

  // Construct the sentence based on the selected language
  const sentence = stickers
    .map((sticker) => {
      // Determine which name to use based on the language
      return language === "en" ? sticker.en : sticker.ar;
    })
    .join(separator);

  return sentence;
}

// Advanced usage examples
function demonstrateSentenceConstruction() {
  // Example with Arabic letters
  const arabicLettersSentence = "1-2-3-4-5";
  console.log(
    "Arabic Letters Sentence (English):",
    constructSentenceFromStickers(arabicLettersSentence, { language: "en" })
  );
  console.log(
    "Arabic Letters Sentence (Arabic):",
    constructSentenceFromStickers(arabicLettersSentence, { language: "ar" })
  );

  // Example with English letters
  const englishLettersSentence = "29-30-31-32-33";
  console.log(
    "English Letters Sentence (English):",
    constructSentenceFromStickers(englishLettersSentence, { language: "en" })
  );
  console.log(
    "English Letters Sentence (Arabic):",
    constructSentenceFromStickers(englishLettersSentence, { language: "ar" })
  );

  // Mixed example
  const mixedSentence = "1-29-2-30-3-31";
  console.log(
    "Mixed Letters Sentence (English):",
    constructSentenceFromStickers(mixedSentence, { language: "en" })
  );
}

// Render function for chat messages
const renderStickerMessage = ({ item }: { item: any }) => {
  if (typeof item.content !== "string") return null;

  // Determine language dynamically or use a default
  const sentence = constructSentenceFromStickers(item.content, {
    language: "en", // or dynamically set based on user preference
  });

  return (
    <View style={tw`bg-white p-2 rounded`}>
      <Text>{sentence}</Text>
    </View>
  );
};

// Additional utility function to classify sticker type
function classifyStickerType(id: string): string {
  const numId = parseInt(id);

  if (numId >= 1 && numId <= 28) return "Arabic Letter";
  if (numId >= 29 && numId <= 55) return "English Letter";
  if (numId >= 56 && numId <= 59) return "Punctuation";

  return "Unknown";
}

// More detailed rendering with type information
const renderDetailedStickerMessage = ({ item }: { item: any }) => {
  if (typeof item.content !== "string") return null;

  const ids = item.content.split("-");

  return (
    <View style={tw`bg-white p-2 rounded`}>
      {ids.map((id: string, index: number) => {
        const sticker: Sticker | undefined = allStickers.find(
          (s: Sticker) => s.id === id
        );
        const type: string = classifyStickerType(id);

        return sticker ? (
          <View key={index} style={tw`flex-row items-center mb-1`}>
            <Image
              source={sticker.path}
              style={tw`w-10 h-10 mr-2`}
              resizeMode="contain"
            />
            <View>
              <Text>{sticker.en}</Text>
              <Text style={tw`text-xs text-gray-500`}>{type}</Text>
            </View>
          </View>
        ) : null;
      })}
    </View>
  );
};

export {
  constructSentenceFromStickers,
  classifyStickerType,
  renderStickerMessage,
  renderDetailedStickerMessage,
};
