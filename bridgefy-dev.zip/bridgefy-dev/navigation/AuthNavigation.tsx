import React from "react";

import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";

import ChatContextProvider from "../context/socketContext";
import ForgetPasswordScreen from "../screens/ForgetPasswordScreen";
import LoginScreen from "../screens/LoginScreen";
import ResetPasswordScreen from "../screens/ResetPasswordScreen";
import SignUpFirstStepScreen from "../screens/SignUpFirstStepScreen";
import SignUpSecondStepScreen from "../screens/SignUpSecondStepScreen";
import SignUpThirdStepScreen from "../screens/SignUpThirdStepScreen";
import WelcomeScreen from "../screens/WelcomeScreen";
import ProfileUpdateScreen from "../screens/ProfileUpdateScreen ";

type RootStackParamList = {
  Welcome: undefined;
  SignUpFirstStep: undefined;
  Login: undefined;
  SignUp: undefined;
  ResetPassword: undefined;
  Chat: undefined;
  Home: undefined;
  ProflieSetting: undefined;
  SignUpSecondStep: undefined;
  ForgetPassword: undefined;
  SignUpThirdStep: undefined;
  StickerStoreScreen: undefined;
  StickerStore: undefined;
  ProfileUpdate: undefined;
};

const Stack = createStackNavigator<RootStackParamList>();

const AuthNavigator = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator
        initialRouteName={"Welcome"}
        screenOptions={{
          headerShown: false,
          cardStyle: { backgroundColor: "white" },
        }}
      >
        <Stack.Screen name="Welcome" component={WelcomeScreen} />
        <Stack.Screen
          name="SignUpFirstStep"
          component={SignUpFirstStepScreen}
        />
        <Stack.Screen name="Login" component={LoginScreen} />
        <Stack.Screen
          name="SignUpSecondStep"
          component={SignUpSecondStepScreen}
        />

        <Stack.Screen name="ForgetPassword" component={ForgetPasswordScreen} />
        <Stack.Screen
          name="SignUpThirdStep"
          component={SignUpThirdStepScreen}
        />
        <Stack.Screen name="ResetPassword" component={ResetPasswordScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

export default AuthNavigator;
