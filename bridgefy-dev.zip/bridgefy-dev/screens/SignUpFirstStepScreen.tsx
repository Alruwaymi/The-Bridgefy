// src/screens/SignUpFirstStepScreen.tsx

import React, { useState } from "react";
import {
  View,
  TextInput,
  Text,
  TouchableOpacity,
  Alert,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  Image,
} from "react-native";
import tw from "../tailwind";
import CustomHeader from "../comp/CustomHeader";
import useStore from "../store/useStore";
import * as ImagePicker from "expo-image-picker";
import { convertImageToBase64 } from "../utils/basa64";
const SignUpFirstStepScreen = ({ navigation }: { navigation: any }) => {
  const { updateSignUpData, signUpData } = useStore();
  const [profileImage, setProfileImage] = useState<any>(null);
  const [firstName, setFirstName] = useState(signUpData.firstName || "");
  const [lastName, setLastName] = useState(signUpData.lastName || "");
  const [email, setEmail] = useState(signUpData.email || "");
  const [password, setPassword] = useState(signUpData.password || "");

  const pickImage = async () => {
    // Request permission
    const permissionResult =
      await ImagePicker.requestMediaLibraryPermissionsAsync();

    if (!permissionResult.granted) {
      Alert.alert(
        "Permission Denied",
        "We need access to your camera roll to upload images."
      );
      return;
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.4,
    });

    if (!result.canceled && result.assets && result.assets.length > 0) {
      const base64 = await convertImageToBase64(result.assets[0].uri);
      setProfileImage(base64);
    }
  };

  const handleSubmit = () => {
    if (!firstName || !lastName || !email || !password) {
      Alert.alert("Error", "Please fill in all fields.");
      return;
    }

    // Update the sign-up data in the store
    updateSignUpData({ profileImage, firstName, lastName, email, password });

    // Navigate to the second step
    navigation.navigate("SignUpSecondStep");
  };

  return (
    <View style={tw`flex-1 bg-white`}>
      <CustomHeader />
      <KeyboardAvoidingView
        style={tw`flex-1`}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
        keyboardVerticalOffset={Platform.OS === "ios" ? 0 : 0}
      >
        <ScrollView
          contentContainerStyle={tw`px-8 pb-8`}
          keyboardShouldPersistTaps="handled"
        >
          {/* Welcome Text */}
          <View style={tw`items-center mb-6`}>
            <View style={tw`px-4 py-2 rounded-lg py-3 border border-gray-200`}>
              <Text style={tw`text-sm font-semibold`}>Create Account</Text>
            </View>
          </View>
          <View style={tw`items-center mb-6`}>
            <TouchableOpacity onPress={pickImage}>
              {profileImage ? (
                <Image
                  source={{ uri: profileImage }}
                  style={tw`w-32 h-32 rounded-full`}
                />
              ) : (
                <View
                  style={tw`w-32 h-32 rounded-full bg-gray-300 items-center justify-center`}
                >
                  <Text style={tw`text-white text-2xl`}>+</Text>
                </View>
              )}
            </TouchableOpacity>
          </View>

          <View style={tw`border border-gray-200 p-6 rounded-lg gap-4`}>
            {/* Input Fields */}
            <View style={tw`mb-4`}>
              <Text style={tw`text-gray-700 mb-2`}>First Name</Text>
              <TextInput
                placeholder="Your first name"
                value={firstName}
                onChangeText={setFirstName}
                style={tw`bg-gray-100 py-3 px-4 rounded-xl border border-gray-200`}
                returnKeyType="next"
                onSubmitEditing={() => {}}
              />
            </View>
            <View style={tw`mb-4`}>
              <Text style={tw`text-gray-700 mb-2`}>Last Name</Text>
              <TextInput
                placeholder="Your last name"
                value={lastName}
                onChangeText={setLastName}
                style={tw`bg-gray-100 py-3 px-4 rounded-xl border border-gray-200`}
                returnKeyType="next"
                onSubmitEditing={() => {}}
              />
            </View>
            <View style={tw`mb-4`}>
              <Text style={tw`text-gray-700 mb-2`}>Email</Text>
              <TextInput
                placeholder="Email"
                value={email}
                onChangeText={setEmail}
                autoCapitalize="none"
                keyboardType="email-address"
                style={tw`bg-gray-100 py-3 px-4 rounded-xl border border-gray-200`}
                returnKeyType="next"
                onSubmitEditing={() => {}}
              />
            </View>

            <View style={tw`mb-4`}>
              <Text style={tw`text-gray-700 mb-2`}>Password</Text>
              <TextInput
                placeholder="Password"
                value={password}
                onChangeText={setPassword}
                secureTextEntry
                style={tw`bg-gray-100 py-3 px-4 rounded-xl border border-gray-200`}
                returnKeyType="done"
                onSubmitEditing={handleSubmit}
              />
            </View>

            {/* Next Button */}
            <TouchableOpacity
              style={tw`bg-black py-3 px-6 rounded-xl items-center`}
              onPress={handleSubmit}
            >
              <Text style={tw`text-white text-base`}>Next</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
};

export default SignUpFirstStepScreen;
