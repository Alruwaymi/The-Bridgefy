import React, { useState } from "react";
import {
  View,
  TextInput,
  Text,
  TouchableOpacity,
  Alert,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
} from "react-native";
import tw from "../tailwind";
import CustomHeader from "../comp/CustomHeader";
import axiosInstance from "../api/axiosInstance";

interface ResetPasswordScreenProps {
  navigation: any;
  route: {
    params: {
      email: string;
    };
  };
}

const ResetPasswordScreen = ({
  navigation,
  route,
}: any) => {
  const { email } = route.params;

  const [code, setCode] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [attemptsLeft, setAttemptsLeft] = useState(3);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async () => {
    if (!code || !newPassword) {
      Alert.alert("Error", "Please enter the code and your new password.");
      return;
    }

    setIsSubmitting(true);

    try {
      // Send the code, new password, and email to the backend
      const response = await axiosInstance.post("/auth/reset-password", {
        email,
        code,
        newPassword,
      });

      // Assuming the response indicates success
      Alert.alert("Success", "Your password has been reset.", [
        {
          text: "OK",
          onPress: () => navigation.replace("Login"),
        },
      ]);
    } catch (error: any) {
      let errorMessage = "An error occurred. Please try again.";
      if (
        error.response &&
        error.response.data &&
        error.response.data.message
      ) {
        errorMessage = error.response.data.message;
      }

      setAttemptsLeft((prev) => prev - 1);

      if (attemptsLeft - 1 > 0) {
        Alert.alert(
          "Error",
          `${errorMessage}\nYou have ${attemptsLeft - 1} attempt(s) left.`
        );
      } else {
        Alert.alert("Error", "Maximum attempts reached. Please try again.", [
          {
            text: "OK",
            onPress: () => navigation.replace("ForgetPassword"),
          },
        ]);
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <View style={tw`flex-1 bg-white`}>
      <CustomHeader />
      <KeyboardAvoidingView
        style={tw`flex-1 justify-center`}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
        keyboardVerticalOffset={Platform.OS === "ios" ? 0 : 0}
      >
        <ScrollView
          contentContainerStyle={tw`px-8 pb-8`}
          keyboardShouldPersistTaps="handled"
        >
          {/* Title */}
          <View style={tw`items-center mb-6 mt-40`}>
            <Text style={tw`text-lg font-semibold`}>Reset Password</Text>
          </View>

          <View style={tw`p-6 border border-gray-200 rounded-lg`}>
            <View style={tw`mb-4`}>
              <Text style={tw`text-gray-700 mb-2`}>Email</Text>
              <Text
                style={tw`bg-gray-100 py-3 px-4 rounded-lg border border-gray-200 mb-5`}
              >
                {email}
              </Text>
            </View>

            <View style={tw`mb-4`}>
              <Text style={tw`text-gray-700 mb-2`}>Reset Code</Text>
              <TextInput
                placeholder="Enter the code you received"
                value={code}
                onChangeText={setCode}
                style={tw`bg-gray-100 py-3 px-4 rounded-lg border border-gray-200 mb-5`}
                returnKeyType="next"
                onSubmitEditing={() => {}}
              />
            </View>

            <View style={tw`mb-4`}>
              <Text style={tw`text-gray-700 mb-2`}>New Password</Text>
              <TextInput
                placeholder="Enter your new password"
                value={newPassword}
                onChangeText={setNewPassword}
                secureTextEntry
                style={tw`bg-gray-100 py-3 px-4 rounded-lg border border-gray-200 mb-5`}
                returnKeyType="done"
                onSubmitEditing={handleSubmit}
              />
            </View>

            <TouchableOpacity
              style={tw`bg-black py-3 px-4 rounded-lg`}
              onPress={handleSubmit}
              disabled={isSubmitting || attemptsLeft <= 0}
            >
              <Text style={tw`text-white text-md font-regular`}>
                {isSubmitting ? "Submitting..." : "Reset Password"}
              </Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
};

export default ResetPasswordScreen;
