import React, { useState } from "react";

import { Text, TouchableOpacity, View } from "react-native";

import { FontAwesome6, Ionicons } from "@expo/vector-icons";

import CustomFooter from "../comp/CustomFooter";
import GeneralSettings from "../comp/Setting/GeneralSettings";
import Rooms from "../comp/Room/Rooms";
import tw from "../tailwind";

const HomeScreen = ({ navigation }: { navigation: any }) => {
  const [currentRoute, setCurrentRoute] = useState("rooms");
  const handleNavigateToRooms = () => {
    setCurrentRoute("rooms");
  };
  const handleNavigateToSettings = () => {
    setCurrentRoute("settings");
  };

  return (
    <View style={tw`flex-1 bg-gray-100`}>
      {currentRoute === "settings" ? (
        <GeneralSettings navigation={navigation} />
      ) : (
        <>
          <Rooms navigation={navigation} />
        </>
      )}
      <CustomFooter
        currentRoute={currentRoute}
        handleNavigateToRooms={handleNavigateToRooms}
        handleNavigateToSettings={handleNavigateToSettings}
      />
    </View>
  );
};

export default HomeScreen;
