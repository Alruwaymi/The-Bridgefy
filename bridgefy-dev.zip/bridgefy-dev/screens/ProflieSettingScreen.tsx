import React, { useEffect } from "react";

import { Image, Text, TouchableOpacity, View } from "react-native";

import { Ionicons } from "@expo/vector-icons";

import CustomHeader from "../comp/CustomHeader";
import useStore from "../store/useStore";
import tw from "../tailwind";
import { useSecureUser } from "../hooks/secureUser";

const ProflieSettingScreen = () => {
  const { user } = useSecureUser();

  const InfoData = [
    { label: "Name", icon: "person-outline", value: user?.fullName },
    { label: "Email", icon: "mail-outline", value: user?.email },
    {
      label: "User Type",
      icon: "information-circle-outline",
      value: user?.status,
    },
  ];

  return (
    <View style={tw`flex-1 bg-white px-6`}>
      <CustomHeader />
      <View style={tw`items-center mt-12 `}>
        <TouchableOpacity
          style={tw`w-24 h-24 rounded-full border border-borderColor items-center justify-center mb-2 shadow`}
        >
          <Image
            source={{ uri: user?.profileImage }}
            style={tw`w-44 h-44 rounded-full shadow`}
          />
        </TouchableOpacity>
      </View>
      <View
        style={tw`bg-white mt-16 p-4 rounded-xl flex-col items-center shadow border-b border-borderColor w-full mx-auto  `}
      >
        {InfoData.map((item, index) => (
          <CustomField
            key={index}
            label={item.label}
            icon={item.icon}
            //@ts-ignore
            value={item?.value}
            showDivider={index !== InfoData.length - 1}
          />
        ))}
      </View>
    </View>
  );
};

export default ProflieSettingScreen;

const CustomField = ({
  icon,
  label,
  value,
  showDivider,
}: {
  icon: string;
  label: string;
  value: string;
  showDivider: boolean;
}) => {
  return (
    <View style={tw`py-3 `}>
      <View style={tw`flex-row justify-between items-center px-1 w-full`}>
        <Ionicons
          //@ts-ignore
          // name={"information-circle-outline"}
          name={icon}
          size={24}
          color="black"
        />
        <View style={tw`flex-col justify-between gap-2 px-1 w-full`}>
          <Text style={tw`ml-4 text-[12px] text-gray2`}>{label}</Text>
          <Text style={tw`ml-4 text-sm text-black`}>{value}</Text>
        </View>
      </View>
      {showDivider && <View style={tw`h-[1px] bg-gray-200 mt-2`} />}
    </View>
  );
};
