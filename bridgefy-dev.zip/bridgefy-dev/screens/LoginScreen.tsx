import React, { useState } from "react";
import {
  View,
  TextInput,
  Text,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
} from "react-native";
import tw from "../tailwind";
import CustomHeader from "../comp/CustomHeader";
import useStore from "../store/useStore";
import { CommonActions } from "@react-navigation/native";

const LoginScreen = ({ navigation }: { navigation: any }) => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const { login, loading } = useStore();

  const handleForgetPassword = () => {
    navigation.navigate("ForgetPassword");
  };

  // Function to handle form submission
  const handleSubmit = async () => {
    // Validate input
    if (!email || !password) {
      Alert.alert("Error", "Please enter email and password.");
      return;
    }

    // Call the login action from the store
    await login(email, password);

    // Access updated user and error state after login action

    // navigation.replace("ProfileUpdate");
    // if (updatedUser) {
    //   // Navigate to the Home screen upon successful login
    //   Alert.alert(
    //     "Update Profile",
    //     "Would you like to update your profile information?",
    //     [
    //       {
    //         text: "Later",
    //         onPress: () => navigation.replace("Home"),
    //       },
    //       {
    //         text: "Yes",
    //       },
    //     ],
    //     { cancelable: false }
    //   );
    // } else if (updatedError) {
    //   // Show an error alert if login failed
    //   Alert.alert("Login Failed", updatedError);
    // }
  };

  return (
    <View style={tw`flex-1 bg-white px-12`}>
      <CustomHeader />

      {/* Welcome Back Text */}
      <View style={tw`items-center mb-6`}>
        <View style={tw`bg-gray-100 px-4 py-2 rounded-lg`}>
          <Text style={tw`text-sm font-semibold`}>Welcome Back</Text>
        </View>
      </View>

      {/* Input Fields */}
      <View style={tw`mb-4`}>
        <Text style={tw`text-gray-700 mb-2`}>Email</Text>
        <TextInput
          placeholder="Email"
          value={email}
          onChangeText={setEmail}
          autoCapitalize="none"
          keyboardType="email-address"
          style={tw`bg-gray-100 py-3 px-4 rounded-lg border border-gray-200 mb-5`}
        />
      </View>

      <View style={tw`mb-4`}>
        <Text style={tw`text-gray-700 mb-2`}>Password</Text>
        <TextInput
          placeholder="Password"
          value={password}
          onChangeText={setPassword}
          secureTextEntry
          style={tw`bg-gray-100 py-3 px-4 rounded-lg border border-gray-200 mb-2`}
        />
      </View>

      {/* Forgot Password */}
      <TouchableOpacity style={tw`mb-6`} onPress={handleForgetPassword}>
        <Text style={tw`text-sm text-blue-600`}>Forgot password?</Text>
      </TouchableOpacity>

      {/* Login Button */}
      <TouchableOpacity
        style={tw`bg-black py-3 px-6 rounded-lg items-center mt-4`}
        onPress={handleSubmit}
        disabled={loading}
      >
        {loading ? (
          <ActivityIndicator color="#fff" />
        ) : (
          <Text style={tw`text-white text-md font-regular`}>Log in</Text>
        )}
      </TouchableOpacity>
    </View>
  );
};

export default LoginScreen;
