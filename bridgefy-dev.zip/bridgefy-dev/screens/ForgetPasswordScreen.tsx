import React, { useState } from "react";
import {
  View,
  TextInput,
  Text,
  TouchableOpacity,
  Alert,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
} from "react-native";
import tw from "../tailwind";
import CustomHeader from "../comp/CustomHeader";
import useStore from "../store/useStore";
import axiosInstance from "../api/axiosInstance";

const ForgetPasswordScreen = ({ navigation }: { navigation: any }) => {
  const [email, setEmail] = useState("");
  const { loading, error } = useStore();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleCancel = () => {
    navigation.navigate("Login");
  };

  const handleSubmit = async () => {
    if (!email) {
      Alert.alert("Error", "Please enter your email.");
      return;
    }

    setIsSubmitting(true);

    try {
      // Send the email to the backend to initiate password reset
      const response = await axiosInstance.post("/auth/forgot-password", {
        email,
      });

      // Assuming the response has a success message
      Alert.alert("Success", "A reset code has been sent to your email.", [
        {
          text: "OK",
          onPress: () => navigation.navigate("ResetPassword", { email }),
        },
      ]);
    } catch (error: any) {
      let errorMessage = "An error occurred. Please try again.";
      if (
        error.response &&
        error.response.data &&
        error.response.data.message
      ) {
        errorMessage = error.response.data.message;
      }
      Alert.alert("Error", errorMessage);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <View style={tw`flex-1 bg-white`}>
      <CustomHeader />
      <KeyboardAvoidingView
        style={tw`flex-1 justify-center`}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
        keyboardVerticalOffset={Platform.OS === "ios" ? 0 : 0}
      >
        <ScrollView
          contentContainerStyle={tw`px-8 pb-8`}
          keyboardShouldPersistTaps="handled"
        >
          {/* Title */}
          <View style={tw`items-center mb-6 mt-40`}>
            <Text style={tw`text-lg font-semibold`}>Reset Account</Text>
          </View>

          <View style={tw`p-6 border border-gray-200 rounded-lg`}>
            <View style={tw`mb-4`}>
              <Text style={tw`text-gray-700 mb-2`}>Email</Text>
              <TextInput
                placeholder="Email"
                value={email}
                onChangeText={setEmail}
                autoCapitalize="none"
                keyboardType="email-address"
                style={tw`bg-gray-100 py-3 px-4 rounded-lg border border-gray-200 mb-5`}
                returnKeyType="done"
                onSubmitEditing={handleSubmit}
              />
            </View>

            <View style={tw`flex-row justify-center items-center gap-6`}>
              <TouchableOpacity onPress={handleCancel}>
                <Text style={tw`text-lg text-black`}>Cancel</Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={tw`bg-black py-3 px-4 rounded-lg`}
                onPress={handleSubmit}
                disabled={isSubmitting}
              >
                <Text style={tw`text-white text-md font-regular`}>
                  {isSubmitting ? "Submitting..." : "Reset Password"}
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
};

export default ForgetPasswordScreen;
