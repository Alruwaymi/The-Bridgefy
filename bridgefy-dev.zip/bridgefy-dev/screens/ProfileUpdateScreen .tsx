// src/screens/ProfileUpdateScreen.tsx

import React, { useEffect, useState } from "react";
import {
  View,
  TextInput,
  Text,
  TouchableOpacity,
  Alert,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  Image,
  ActivityIndicator,
} from "react-native";
import * as ImagePicker from "expo-image-picker";
import tw from "../tailwind";
import CustomHeader from "../comp/CustomHeader";
import useStore from "../store/useStore";
import axiosInstance from "../api/axiosInstance";
import { convertImageToBase64 } from "../utils/basa64";
import { useSecureUser } from "../hooks/secureUser";

const ProfileUpdateScreen = ({ navigation }: { navigation: any }) => {
  const { user, saveUser } = useSecureUser();
  console.log("🚀 ~ ProfileUpdateScreen ~ user:", user);

  const [firstName, setFirstName] = useState(user?.firstName || "");
  const [lastName, setLastName] = useState(user?.lastName || "");
  const [profileImage, setProfileImage] = useState<any>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  useEffect(() => {
    setFirstName(user?.firstName || "");
    setLastName(user?.lastName || "");
  }, [user]);
  // Function to pick image from device
  const pickImage = async () => {
    // Request permission
    const permissionResult =
      await ImagePicker.requestMediaLibraryPermissionsAsync();

    if (!permissionResult.granted) {
      Alert.alert(
        "Permission Denied",
        "We need access to your camera roll to upload images."
      );
      return;
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.8,
    });

    if (!result.canceled && result.assets && result.assets.length > 0) {
      const base64 = await convertImageToBase64(result.assets[0].uri);
      setProfileImage(base64);
    }
  };
  console.log("uhuuuuf", profileImage);

  const handleSubmit = async () => {
    if (!firstName || !lastName) {
      Alert.alert("Error", "Please enter your first and last name.");
      return;
    }

    setIsSubmitting(true);

    try {
      const formData = new FormData();
      formData.append("firstName", firstName);
      formData.append("lastName", lastName);

      if (profileImage) {
        formData.append("profileImage", profileImage);
      }

      const response = await axiosInstance.patch("/users/update", formData);

      console.log("Update re14sponse:", response.data.data);

      const updatedUser = response.data.data;

      saveUser({ ...user, ...updatedUser });

      Alert.alert("Success", "Your profile has been updated.", [
        {
          text: "OK",
          onPress: async () => {
            navigation.replace("Home");
          },
        },
      ]);
    } catch (error: any) {
      console.error("Profile update error:", error);

      let errorMessage = "An error occurred. Please try again.";

      if (error.response) {
        console.log("Error response data:", error.response.data);
        if (error.response.data && error.response.data.message) {
          errorMessage = error.response.data.message;
        }
      } else if (error.request) {
        console.log("Error request:", error.request);
      } else if (error.message) {
        console.log("Error message:", error.message);
        errorMessage = error.message;
      }

      Alert.alert("Error", errorMessage);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <View style={tw`flex-1 bg-white`}>
      <CustomHeader />
      <KeyboardAvoidingView
        style={tw`flex-1`}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
        keyboardVerticalOffset={Platform.OS === "ios" ? 0 : 0}
      >
        <ScrollView
          contentContainerStyle={tw`px-8 pb-8`}
          keyboardShouldPersistTaps="handled"
        >
          {/* Title */}
          <View style={tw`items-center mb-6 mt-10`}>
            <Text style={tw`text-lg font-semibold`}>Update Your Profile</Text>
          </View>

          {/* Profile Image Section */}
          <View style={tw`items-center mb-6`}>
            <TouchableOpacity onPress={pickImage}>
              {profileImage ? (
                <Image
                  source={{ uri: profileImage }}
                  style={tw`w-32 h-32 rounded-full`}
                />
              ) : user?.profileImage ? (
                <Image
                  source={{ uri: user.profileImage }}
                  style={tw`w-32 h-32 rounded-full`}
                />
              ) : (
                <View
                  style={tw`w-32 h-32 rounded-full bg-gray-300 items-center justify-center`}
                >
                  <Text style={tw`text-white text-2xl`}>+</Text>
                </View>
              )}
            </TouchableOpacity>
            <TouchableOpacity
              onPress={pickImage}
              style={tw`mt-4 px-4 py-2 bg-black rounded-full`}
            >
              <Text style={tw`text-white`}>Change Profile Picture</Text>
            </TouchableOpacity>
          </View>

          {/* Input Fields */}
          <View style={tw`mb-4`}>
            <Text style={tw`text-gray-700 mb-2`}>First Name</Text>
            <TextInput
              placeholder="First Name"
              value={firstName}
              onChangeText={setFirstName}
              style={tw`bg-gray-100 py-3 px-4 rounded-lg border border-gray-200`}
            />
          </View>

          <View style={tw`mb-4`}>
            <Text style={tw`text-gray-700 mb-2`}>Last Name</Text>
            <TextInput
              placeholder="Last Name"
              value={lastName}
              onChangeText={setLastName}
              style={tw`bg-gray-100 py-3 px-4 rounded-lg border border-gray-200`}
            />
          </View>

          {/* Submit Button */}
          <TouchableOpacity
            style={tw`bg-black py-3 px-6 rounded-lg items-center mt-4`}
            onPress={handleSubmit}
            disabled={isSubmitting}
          >
            {isSubmitting ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <Text style={tw`text-white text-base`}>Update Profile</Text>
            )}
          </TouchableOpacity>

          {/* Skip Button (Optional) */}
          <TouchableOpacity
            style={tw`mt-4 items-center`}
            onPress={async () => {
              navigation.replace("Home");
            }}
          >
            <Text style={tw`text-blue-600`}>Skip for now</Text>
          </TouchableOpacity>
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
};

export default ProfileUpdateScreen;
