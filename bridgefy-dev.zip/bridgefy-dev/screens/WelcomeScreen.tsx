import React from "react";
import tw from "../tailwind";
import { View, Text, Image, TouchableOpacity } from "react-native";

const WelcomeScreen = ({ navigation }: { navigation: any }) => {
  return (
    <View style={tw`flex-1 justify-center gap-8 items-center bg-white`}>
      <Image source={require("../assets/logo.png")} style={tw`w-[90%] h-80`} />
      <TouchableOpacity
        style={tw`bg-gray1 py-7 px-8 rounded-xl  border border-gray2 mb-5`}
      >
        <Text
          style={tw`text-base text-black text-center`}
        >{`>_Welcome to the Bridgefy`}</Text>
      </TouchableOpacity>
      <View style={tw`flex w-2/5 justify-center gap-4   mb-10`}>
        <TouchableOpacity
          style={tw`rounded-xl  px-3 border border-borderColor`}
          onPress={() => navigation.navigate("Login")}
        >
          <Text
            style={tw`text-textColor text-lg font-regular  py-1  text-center`}
          >
            Log In
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={tw`rounded-xl  px-3 border border-borderColor`}
          onPress={() => navigation.navigate("SignUpFirstStep")}
        >
          <Text
            style={tw`text-textColor text-lg font-regular  py-1  text-center`}
          >
            Sign Up
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default WelcomeScreen;
