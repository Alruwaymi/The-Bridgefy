// src/screens/SignUpSecondStepScreen.tsx

import React from "react";
import {
  View,
  Text,
  TouchableOpacity,
  Alert,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
} from "react-native";
import tw from "../tailwind";
import CustomHeader from "../comp/CustomHeader";
import useStore from "../store/useStore";

const SignUpSecondStepScreen = ({ navigation }: { navigation: any }) => {
  const { updateSignUpData } = useStore();

  const handleSelection = (status: string) => {
    if (!status) {
      Alert.alert("Error", "Please select an option.");
      return;
    }

    // Update the sign-up data with the user's status
    updateSignUpData({ status });

    // Navigate to the third step
    navigation.navigate("SignUpThirdStep");
  };

  return (
    <View style={tw`flex-1 bg-white`}>
      <CustomHeader />
      <KeyboardAvoidingView
        style={tw`flex-1`}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
        keyboardVerticalOffset={Platform.OS === "ios" ? 0 : 0}
      >
        <ScrollView
          contentContainerStyle={tw`px-8 pb-8`}
          keyboardShouldPersistTaps="handled"
        >
          {/* Title */}
          <View
            style={tw`flex-col gap-10 items-center justify-center mb-6 mt-40`}
          >
            <View style={tw`items-center justify-center mb-6`}>
              <View style={tw`px-8 rounded-lg py-3 border border-gray-200`}>
                <Text style={tw`text-lg font-semibold py-2 px-8`}>
                  What are You?
                </Text>
              </View>
            </View>

            {/* Option Buttons */}
            <View style={tw`flex-row items-center justify-center gap-4`}>
              <TouchableOpacity
                style={tw`bg-gray-200 py-3 px-6 rounded-xl items-center`}
                onPress={() => handleSelection("deaf")}
              >
                <Text style={tw`text-black text-base`}>Deaf</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={tw`bg-black py-3 px-6 rounded-xl items-center`}
                onPress={() => handleSelection("hearing")}
              >
                <Text style={tw`text-white text-base`}>Hearing</Text>
              </TouchableOpacity>
            </View>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
};

export default SignUpSecondStepScreen;
