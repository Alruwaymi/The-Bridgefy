import React, { useEffect, useState } from "react";
import * as SecureStore from "expo-secure-store";
import AppNavigator from "./navigation/AppNavigation";
import useStore from "./store/useStore";
import AuthNavigator from "./navigation/AuthNavigation";
import * as Notifications from "expo-notifications";
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: true,
    priority: Notifications.AndroidNotificationPriority.HIGH,
  }),
});
export default function App() {
  const { user } = useStore();

  const [userToken, setUserToken] = useState<string | null>(null);

  const getToken = async () => {
    try {
      // await SecureStore.deleteItemAsync("authToken");
      const token = await SecureStore.getItemAsync("authToken");
      setUserToken(token);
    } catch (error) {
      console.error("Error retrieving token:", error);
      setUserToken(null);
    }
  };

  useEffect(() => {
    getToken();
  }, [user]);

  if (!userToken) {
    return <AuthNavigator />;
  }
  return userToken ? <AppNavigator /> : <AuthNavigator />;
}
