import * as FileSystem from "expo-file-system";
export const convertImageToBase64 = async (uri: string): Promise<string> => {
  try {
    // Read the file
    const base64 = await FileSystem.readAsStringAsync(uri, {
      encoding: FileSystem.EncodingType.Base64,
    });

    // Determine the MIME type based on file extension
    const fileExtension = uri.split(".").pop()?.toLowerCase();
    const mimeType = getMimeType(fileExtension);

    // Return full base64 string with data URL prefix
    return `data:${mimeType};base64,${base64}`;
  } catch (error) {
    console.error("Base64 Conversion Error:", error);
    throw error;
  }
};

// Helper function to get MIME type
export const getMimeType = (fileExtension?: string): string => {
  switch (fileExtension) {
    case "jpg":
    case "jpeg":
      return "image/jpeg";
    case "png":
      return "image/png";
    case "gif":
      return "image/gif";
    case "webp":
      return "image/webp";
    default:
      return "application/octet-stream";
  }
};
