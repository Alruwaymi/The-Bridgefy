export interface User {
  id: string;
  name: string;
  image: string;
  lastSeen?: Date;
  isOnline?: boolean;
}

export interface Message {
  id: string;
  content: string;
  type: "text" | "image" | "sticker";
  createdAt: string;
  isRead: boolean;
  readAt?: Date;
  senderId: string;
  fromMe: boolean;
}

export interface ChatRoom {
  id: string;
  name: string;
  image: string;
  lastMessage?: Message;
  unreadCount: number;
}
