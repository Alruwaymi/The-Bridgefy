import React, { useState } from "react";
import {
  FlatList,
  Modal,
  SafeAreaView,
  TextInput,
  TouchableOpacity,
  View,
  ListRenderItem,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import tw from "../../tailwind";
import { Message } from "../../types/chatType";

interface SearchMessageProps {
  searchModalVisible: boolean;
  setSearchModalVisible: (visible: boolean) => void;
  messages: Message[];
  renderMessageItem: ListRenderItem<Message>;
}

const SearchMessage: React.FC<SearchMessageProps> = ({
  searchModalVisible,
  setSearchModalVisible,
  messages,
  renderMessageItem,
}) => {
  const [searchText, setSearchText] = useState<string>("");
  const [filteredMessages, setFilteredMessages] = useState<Message[]>(messages);

  const handleSearch = (text: string) => {
    setSearchText(text);

    if (text.trim() === "") {
      setFilteredMessages(messages);
    } else {
      const filtered = messages.filter((message) =>
        message.content.toLowerCase().includes(text.toLowerCase())
      );
      setFilteredMessages(filtered);
    }
  };

  return (
    <Modal
      visible={searchModalVisible}
      animationType="slide"
      onRequestClose={() => setSearchModalVisible(false)}
    >
      <SafeAreaView style={tw`flex-1 bg-gray-100`}>
        {/* Search Header */}
        <View
          style={tw`flex-row items-center px-4 py-2 shadow-sm border-b border-gray-300`}
        >
          <TouchableOpacity onPress={() => setSearchModalVisible(false)}>
            <Ionicons name="arrow-back" size={24} color="black" />
          </TouchableOpacity>
          <TextInput
            style={tw`flex-1 bg-gray-200 rounded-full px-4 py-2 mx-4`}
            placeholder="Search messages"
            value={searchText}
            onChangeText={handleSearch}
            autoFocus
          />
        </View>
        {/* Search Results */}
        <FlatList
          data={filteredMessages}
          keyExtractor={(item) => item.id}
          renderItem={renderMessageItem}
          contentContainerStyle={tw`flex-grow`}
        />
      </SafeAreaView>
    </Modal>
  );
};

export default SearchMessage;
