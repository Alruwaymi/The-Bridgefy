import React, { useEffect, useState } from "react";

import { Image, Text, TouchableOpacity, View } from "react-native";

import {
  FontAwesome6,
  Ionicons,
  MaterialCommunityIcons,
} from "@expo/vector-icons";

import axiosInstance from "../../api/axiosInstance";
import { useSecureUser } from "../../hooks/secureUser";
import tw from "../../tailwind";

// const firstSection = [
//   // { label: "Advertise", icon: "megaphone-outline" },
//   { label: "Business tools", icon: "briefcase-outline" },
// ];
const secondSection = [
  // { label: "Broadcast lists", icon: "megaphone-outline" },
  // { label: "Started messge", icon: "star-outline" },
  // { label: "Communites", icon: "people-circle-outline" },
  { label: "About", icon: "laptop-outline" },
];
const GeneralSettings = ({ navigation }: { navigation: any }) => {
  // const { setUser } = useStore();

  const { user, saveUser } = useSecureUser();
  const translationMethod = user?.translationMethod;
  console.log("🚀 ~ GeneralSettings ~ user:", translationMethod);
  const [currentTranlation, setCurrentTranslation] = useState<
    string | undefined
  >(user?.translationMethod);

  // Synchronize currentTranlation with user.translationMethod
  useEffect(() => {
    if (user?.translationMethod) {
      setCurrentTranslation(user.translationMethod);
    }
  }, [user]);
  const handleProfileSetting = () => {
    navigation.navigate("ProflieSetting");
  };

  const handleSubmit = async (newMethod = "text") => {
    setCurrentTranslation(newMethod);
    try {
      // Create FormData
      const data = {
        translationMethod: newMethod,
      };
      // Make the PATCH request to update the profile
      const response = await axiosInstance.patch("/users/update", data);

      console.log("Update re14sponse:", response.data.data);

      // Update the user in the store
      const updatedUser = response.data.data;

      // Merge the updatedUser data with the existing user data
      saveUser({ ...user, ...updatedUser });
    } catch (error: any) {
      console.error("Profile update error:", error);

      let errorMessage = "An error occurred. Please try again.";

      if (error.response) {
        console.log("Error response data:", error.response.data);
        if (error.response.data && error.response.data.message) {
          errorMessage = error.response.data.message;
        }
      } else if (error.request) {
        console.log("Error request:", error.request);
      } else if (error.message) {
        console.log("Error message:", error.message);
        errorMessage = error.message;
      }
    }
  };
  return (
    <>
      {/* Header */}
      <View style={tw`bg-white h-20`} />
      <View style={tw`  pt-5 px-6`}>
        <Text style={tw`text-black text-4xl font-extrabold`}>Settings</Text>
      </View>

      {/* Profile Section */}
      <View
        style={tw`bg-white m-4 p-4 rounded-xl flex-col items-center shadow border-b border-borderColor`}
      >
        <TouchableOpacity
          onPress={handleProfileSetting}
          style={tw`flex-row items-center pb-2 border-b border-borderColor`}
        >
          <Image
            // source={{ uri: "/assets/icon.png" }}

            source={{ uri: user?.profileImage }}
            style={tw`w-14 h-14 rounded-full shadow`}
          />
          <View style={tw`ml-4 flex-1`}>
            <Text style={tw`text-lg font-bold text-black`}>
              {user?.fullName}
            </Text>
            <Text style={tw`text-gray-500 text-sm`}>مرحبا</Text>
          </View>
          <Ionicons
            name="cloud-upload-outline"
            style={tw`rounded-full bg-pink1 p-3`}
            size={20}
            color="black"
          />
        </TouchableOpacity>
        <CustomField
          onPress={() => navigation.navigate("ProfileUpdate")}
          label="Profile"
          icon="person-outline"
          showDivider={false}
        />
      </View>

      {/* Menu Items */}
      <View
        style={tw`bg-white m-4 p-4 rounded-xl flex-col justify-center shadow   `}
      >
        <View style={tw` flex-row gap-3 p-2  border-gray1`}>
          <View style={tw`p-2 rounded-lg bg-gray1 border`}>
            <Image
              source={require("../../assets/translation.png")}
              style={tw`    w-6 h-6`}
            />
          </View>
          <TouchableOpacity
            onPress={() => handleSubmit("text")}
            style={tw` rounded-lg border border-black ${
              currentTranlation === "text" ? "bg-black" : "bg-gray1"
            }  flex-row gap-2 px-8 py-1 justify-center items-center`}
          >
            <Ionicons
              name={"document-text-outline"}
              size={20}
              color={currentTranlation === "text" ? "white" : "black"}
            />
            <Text
              style={tw`font-semibold ${
                currentTranlation === "text" ? "text-white" : "text-black"
              }`}
            >
              Text
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => handleSubmit("sticker")}
            style={tw` rounded-lg border-black  ${
              currentTranlation === "sticker" ? "bg-black" : "bg-gray1"
            } flex-row gap-2 px-8 py-1 justify-center items-center`}
          >
            <MaterialCommunityIcons
              name="sticker-circle-outline"
              size={20}
              color={currentTranlation === "sticker" ? "white" : "black"}
            />
            <Text
              style={tw`font-semibold ${
                currentTranlation === "sticker" ? "text-white" : "text-black"
              }`}
            >
              Sticker
            </Text>
          </TouchableOpacity>
          <View style={tw`h-[1px] bg-gray-200 mt-2`} />
        </View>
      </View>
      <View
        style={tw`bg-white m-4 p-4 rounded-xl flex-col items-center shadow border-b border-borderColor  `}
      >
        <CustomField
          onPress={() => navigation.navigate("About")}
          label={"About"}
          icon={"information-circle-outline"}
          showDivider={false}
        />
      </View>
    </>
  );
};

export default GeneralSettings;

const CustomField = ({
  onPress,
  icon,
  label,
  showDivider,
}: {
  onPress: () => void;
  icon: string;
  label: string;
  showDivider: boolean;
}) => {
  return (
    <View style={tw`pt-1`}>
      <TouchableOpacity
        style={tw`flex-row justify-between items-center px-4`}
        onPress={onPress}
      >
        <View style={tw`bg-white  flex-row items-center w-full`}>
          <Ionicons
            //@ts-ignore
            // name={"information-circle-outline"}
            name={icon}
            size={20}
            color="black"
          />
          <Text style={tw`ml-4 text-black text-lg`}>{label}</Text>
        </View>
        <FontAwesome6
          name="angle-right"
          size={20}
          color="gray"
          style={tw`pt-2 `}
        />
      </TouchableOpacity>

      {showDivider && <View style={tw`h-[1px] bg-gray-200 mt-2`} />}
    </View>
  );
};
