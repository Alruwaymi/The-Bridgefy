import React, { useEffect, useState } from "react";
import {
  ActivityIndicator,
  FlatList,
  Image,
  Modal,
  SafeAreaView,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import tw from "../../tailwind";

import {
  stickers,
  stickerIcons,
  punctuationMarks,
  allStickers,
} from "../../const/sticker";

interface Sticker {
  id: number;
  path: any;
  en: string;
  ar: string;
}

interface StickersCompProps {
  sendStickerMessage: (sticker: Sticker) => void;
  setStickerPickerVisible: (visible: boolean) => void;
  isStickerPickerVisible: boolean;
}

type FilterType = "all" | "gestures" | "icons" | "punctuation";
type LanguageType = "en" | "ar";

export const StickersComp: React.FC<StickersCompProps> = ({
  sendStickerMessage,
  setStickerPickerVisible,
  isStickerPickerVisible,
}) => {
  const [activeStickers, setActiveStickers] = useState<Sticker[]>([]);
  const [searchText, setSearchText] = useState("");
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [activeFilter, setActiveFilter] = useState<FilterType>("all");
  const [language, setLanguage] = useState<LanguageType>("en");

  const filters = [
    {
      id: "all",
      label: { en: "All", ar: "الكل" },
      data: allStickers,
    },
    {
      id: "gestures",
      label: { en: "Gestures", ar: "الإشارات" },
      data: stickers,
    },
    {
      id: "icons",
      label: { en: "Icons", ar: "الرموز" },
      data: stickerIcons,
    },
    {
      id: "punctuation",
      label: { en: "Punctuation", ar: "علامات الترقيم" },
      data: punctuationMarks,
    },
  ];

  useEffect(() => {
    if (isStickerPickerVisible) {
      handleFilterChange("all");
    }
  }, [isStickerPickerVisible]);

  const handleFilterChange = (filterType: FilterType) => {
    setActiveFilter(filterType);
    const filteredData = filters.find((f) => f.id === filterType)?.data || [];

    if (searchText) {
      handleSearch(searchText, filteredData);
    } else {
      setActiveStickers(filteredData);
    }
  };

  const handleSearch = (
    text: string,
    currentData = filters.find((f) => f.id === activeFilter)?.data || []
  ) => {
    setSearchText(text);
    setIsLoading(true);

    const filteredStickers = currentData.filter(
      (sticker) =>
        sticker.en.toLowerCase().includes(text.toLowerCase()) ||
        sticker.ar.includes(text)
    );

    setActiveStickers(filteredStickers);
    setIsLoading(false);
  };

  const toggleLanguage = () => {
    setLanguage((prev) => (prev === "en" ? "ar" : "en"));
  };

  return (
    <Modal
      visible={isStickerPickerVisible}
      animationType="slide"
      onRequestClose={() => setStickerPickerVisible(false)}
    >
      <SafeAreaView style={tw`flex-1 bg-white`}>
        {/* Header */}
        <View style={tw`px-4 py-2 bg-white shadow-sm`}>
          <View style={tw`flex-row items-center`}>
            <TouchableOpacity onPress={() => setStickerPickerVisible(false)}>
              <Ionicons name="close" size={24} color="black" />
            </TouchableOpacity>

            {/* Language Toggle Button */}
            <TouchableOpacity
              onPress={toggleLanguage}
              style={tw`mx-2 px-3 py-1 bg-gray-200 rounded-full`}
            >
              <Text>{language.toUpperCase()}</Text>
            </TouchableOpacity>

            <TextInput
              style={tw`flex-1 bg-gray-100 rounded-full px-4 py-2 mx-4`}
              placeholder={
                language === "en" ? "Search gestures" : "البحث عن الإشارات"
              }
              value={searchText}
              onChangeText={(text) => handleSearch(text)}
              autoFocus
            />
            {searchText !== "" && (
              <TouchableOpacity
                onPress={() => {
                  setSearchText("");
                  handleFilterChange(activeFilter);
                }}
              >
                <Ionicons name="close-circle" size={24} color="gray" />
              </TouchableOpacity>
            )}
          </View>

          {/* Filter Tabs */}
          <View style={tw`flex-row justify-between mt-4`}>
            {filters.map((filter) => (
              <TouchableOpacity
                key={filter.id}
                onPress={() => handleFilterChange(filter.id as FilterType)}
                style={tw`flex-1 items-center py-2 mx-1 rounded-full ${
                  activeFilter === filter.id ? "bg-blue-500" : "bg-gray-200"
                }`}
              >
                <Text
                  style={tw`text-xs py-1 ${
                    activeFilter === filter.id ? "text-white" : "text-black"
                  }`}
                >
                  {filter.label[language]}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Stickers Grid */}
        {isLoading ? (
          <View style={tw`flex-1 justify-center items-center`}>
            <ActivityIndicator size="large" color="#0000ff" />
            <Text>{language === "en" ? "Loading..." : "جاري التحميل..."}</Text>
          </View>
        ) : (
          <FlatList
            data={activeStickers}
            keyExtractor={(item) => item.id.toString()}
            numColumns={4}
            renderItem={({ item }) => (
              <TouchableOpacity
                onPress={() => sendStickerMessage(item)}
                style={tw`flex-1 items-center justify-center p-2`}
              >
                <Image
                  source={item.path}
                  style={{ width: 80, height: 80 }}
                  resizeMode="contain"
                />
                <Text style={tw`text-xs text-center mt-1`}>
                  {language === "en" ? item.en : item.ar}
                </Text>
              </TouchableOpacity>
            )}
            ListEmptyComponent={() => (
              <View style={tw`flex-1 justify-center items-center p-4`}>
                <Text>
                  {language === "en"
                    ? "No gestures found"
                    : "لم يتم العثور على إشارات"}
                </Text>
              </View>
            )}
          />
        )}
      </SafeAreaView>
    </Modal>
  );
};
