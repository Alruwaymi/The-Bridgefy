import React from "react";
import {
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import tw from "../../tailwind";

interface MessageInputProps {
  pickImage: () => void;
  setStickerPickerVisible: (visible: boolean) => void;
  inputText: string;
  setInputText: (text: string) => void;
  sendMessage: () => void;
  isSendingMessageLoading: boolean;
}

const MessageInput: React.FC<MessageInputProps> = ({
  pickImage,
  setStickerPickerVisible,
  inputText,
  setInputText,
  sendMessage,
  isSendingMessageLoading,
}) => {
  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === "ios" ? "padding" : undefined}
      keyboardVerticalOffset={Platform.OS === "ios" ? 90 : 0}
    >
      <View
        style={tw`flex-row items-center border-t border-gray-300 p-2 bg-white`}
      >
        <TouchableOpacity onPress={pickImage} style={tw`mx-1`}>
          <Ionicons name="attach" size={24} color="gray" />
        </TouchableOpacity>

        <TouchableOpacity
          onPress={() => setStickerPickerVisible(true)}
          style={tw`mx-1`}
        >
          <Ionicons name="happy-outline" size={24} color="gray" />
        </TouchableOpacity>
        <TextInput
          style={tw`flex-1 bg-gray-200 rounded-full px-4 py-2 mx-2`}
          placeholder="Type a message"
          value={inputText}
          onChangeText={setInputText}
        />

        <TouchableOpacity
          disabled={isSendingMessageLoading}
          onPress={sendMessage}
          style={tw`mx-1`}
        >
          {isSendingMessageLoading ? (
            <View style={tw`py-4`}>
              <ActivityIndicator size="small" color="#0000ff" />
            </View>
          ) : (
            <Ionicons name="send" size={24} color="#128C7E" />
          )}
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
};

export default MessageInput;
