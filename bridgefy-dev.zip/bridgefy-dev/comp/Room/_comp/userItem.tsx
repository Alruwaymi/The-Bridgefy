import React from "react";
import { View, Text, TouchableOpacity, Image } from "react-native";
import tw from "../../../tailwind";
import { Ionicons } from "@expo/vector-icons";
export interface UserItemProps {
  user: {
    id: string;
    fullName: string;
    profileImage: string;

    lastSeen: Date;
  };
  onPress: () => void;
}

const UserItem: React.FC<UserItemProps> = ({ user, onPress }) => {
  // Format the timestamp
  const formatTime = (dateString: Date) => {
    const date = new Date(dateString);
    return date.toLocaleTimeString([], {
      hour: "2-digit",
      minute: "2-digit",
      hour12: true,
    });
  };

  return (
    <TouchableOpacity
      onPress={onPress}
      style={tw`flex-row items-center p-4 border-b border-gray-100`}
    >
      {/* Profile Image */}
      <Image
        source={{ uri: user.profileImage }}
        style={tw`w-12 h-12 rounded-full mr-4`}
      />

      {/* Chat Details */}
      <View style={tw`flex-1`}>
        {/* Name */}
        <Text style={tw`font-semibold text-base text-black`}>
          {user.fullName}
        </Text>

        {/* Last Message */}
      </View>

      {/* Right Side - Time and Unread Count */}
      <View style={tw`items-end`}>
        {/* Time */}
        {user.lastSeen && (
          <Text style={tw`text-xs text-gray-500 mb-1`}>
            {formatTime(user.lastSeen)}
          </Text>
        )}

        {/* Unread Count */}
      </View>
    </TouchableOpacity>
  );
};

export default UserItem;
