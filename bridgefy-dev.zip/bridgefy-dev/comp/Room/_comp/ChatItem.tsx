// src/screens/_comp/ChatItem.tsx

import React from "react";
import { View, Text, TouchableOpacity, Image } from "react-native";
import tw from "../../../tailwind";
import { Ionicons } from "@expo/vector-icons";
interface ChatItemProps {
  user: {
    id: string;
    name: string;
    image: string;
    lastMessage?: {
      id: string;
      content: string;
      type: string;
      createdAt: string;
      isRead?: boolean;
      readAt?: string;
      senderId?: string;
      fromMe?: boolean;
    };
    unreadMessagesCount: number;
  };
  onPress: () => void;
}

const ChatItem: React.FC<ChatItemProps> = ({ user, onPress }) => {
  // Format the timestamp
  const formatTime = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleTimeString([], {
      hour: "2-digit",
      minute: "2-digit",
      hour12: true,
    });
  };

  return (
    <TouchableOpacity
      onPress={onPress}
      style={tw`flex-row items-center p-4 border-b border-gray-100`}
    >
      {/* Profile Image */}
      <Image
        source={{ uri: user.image }}
        style={tw`w-12 h-12 rounded-full mr-4`}
      />

      {/* Chat Details */}
      <View style={tw`flex-1`}>
        {/* Name */}
        <Text style={tw`font-semibold text-base text-black`}>{user.name}</Text>

        {/* Last Message */}
        {user.lastMessage && (
          <View style={tw`flex-row items-center`}>
            <Text
              numberOfLines={1}
              style={tw`text-gray-500 flex-1 ${
                user.unreadMessagesCount > 0 ? "font-semibold" : ""
              }`}
            >
              {user.lastMessage.type === "sticker" ? (
                <View style={tw`flex-row items-center gap-2`}>
                  <Text>sticker</Text>
                  <Ionicons
                    name="happy-outline"
                    size={18}
                    color="black"
                    style={{ marginRight: 10 }}
                  />
                </View>
              ) : user.lastMessage.type === "image" ? (
                <View style={tw`flex-row items-center gap-2`}>
                  <Text>imge</Text>
                  <Ionicons name="image" size={18} color="black" />
                </View>
              ) : (
                user.lastMessage.content
              )}
            </Text>
          </View>
        )}
      </View>

      {/* Right Side - Time and Unread Count */}
      <View style={tw`items-end`}>
        {/* Time */}
        {user.lastMessage && (
          <Text style={tw`text-xs text-gray-500 mb-1`}>
            {formatTime(user.lastMessage.createdAt)}
          </Text>
        )}

        {/* Unread Count */}
        {user.unreadMessagesCount > 0 && (
          <View
            style={tw`bg-black rounded-full min-w-[20px] h-5 items-center justify-center px-1`}
          >
            <Text style={tw`text-white text-xs`}>
              {user.unreadMessagesCount}
            </Text>
          </View>
        )}
      </View>
    </TouchableOpacity>
  );
};

export default ChatItem;
