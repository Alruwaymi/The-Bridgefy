// src/services/chatService.ts

import axiosInstance from '../api/axiosInstance';

export const chatService = {
  getMessages: async (roomId: string, page: number = 1, pageSize: number = 20) => {
    try {
      const response = await axiosInstance.get(`/rooms/${roomId}/messages`, {
        params: { page, pageSize }
      });
      return response.data?.data;
    } catch (error) {
      console.error('Error fetching messages:', error);
      throw error;
    }
  },

  markAsRead: async (roomId: string) => {
    try {
      await axiosInstance.post(`/rooms/${roomId}/mark-as-read`);
    } catch (error) {
      console.error('Error marking messages as read:', error);
      throw error;
    }
  },

  uploadImage: async (imageUri: string) => {
    try {
      const formData = new FormData();
      const filename = imageUri.split('/').pop() || 'image.jpg';
      
      formData.append('image', {
        uri: imageUri,
        type: 'image/jpeg',
        name: filename,
      } as any);

      const response = await axiosInstance.post('/upload', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });
      return response.data;
    } catch (error) {
      console.error('Error uploading image:', error);
      throw error;
    }
  }
};